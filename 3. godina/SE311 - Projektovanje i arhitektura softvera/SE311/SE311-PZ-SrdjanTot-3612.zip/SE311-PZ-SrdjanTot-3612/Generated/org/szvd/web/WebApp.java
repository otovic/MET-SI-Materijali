/***********************************************************************
 * Module:  WebApp.java
 * Author:  srdjan
 * Purpose: Defines the Class WebApp
 ***********************************************************************/

package org.szvd.web;

import java.util.*;

/** @pdOid c7bb58dd-1a5a-4dcc-9bd6-82068e604d69 */
public class WebApp {
   /** @pdOid 34e20f06-15e7-4a4f-8072-3ef1ebbc1dc6 */
   private java.util.List<org.szvd.web.Controller> controllers;
   
   /** @pdRoleInfo migr=no name=Controller assc=association1 coll=java.util.Collection impl=java.util.HashSet mult=0..* type=Aggregation */
   public java.util.Collection<Controller> controller;
   
   /** @pdOid c17bdcaf-40b1-4691-acef-9d2e98091a2e */
   public WebApp() {
      // TODO: implement
   }
   
   /** @param controller
    * @pdOid 6faad22f-91c5-4809-9979-7cb03b122bf4 */
   public void register(Controller controller) {
      // TODO: implement
   }
   
   /** @param request
    * @pdOid 73fe7d74-8116-4aac-9d89-0fb59a36d616 */
   public java.lang.String routeRequest(java.lang.String request) {
      // TODO: implement
      return null;
   }
   
   
   /** @pdGenerated default getter */
   public java.util.Collection<Controller> getController() {
      if (controller == null)
         controller = new java.util.HashSet<Controller>();
      return controller;
   }
   
   /** @pdGenerated default iterator getter */
   public java.util.Iterator getIteratorController() {
      if (controller == null)
         controller = new java.util.HashSet<Controller>();
      return controller.iterator();
   }
   
   /** @pdGenerated default setter
     * @param newController */
   public void setController(java.util.Collection<Controller> newController) {
      removeAllController();
      for (java.util.Iterator iter = newController.iterator(); iter.hasNext();)
         addController((Controller)iter.next());
   }
   
   /** @pdGenerated default add
     * @param newController */
   public void addController(Controller newController) {
      if (newController == null)
         return;
      if (this.controller == null)
         this.controller = new java.util.HashSet<Controller>();
      if (!this.controller.contains(newController))
         this.controller.add(newController);
   }
   
   /** @pdGenerated default remove
     * @param oldController */
   public void removeController(Controller oldController) {
      if (oldController == null)
         return;
      if (this.controller != null)
         if (this.controller.contains(oldController))
            this.controller.remove(oldController);
   }
   
   /** @pdGenerated default removeAll */
   public void removeAllController() {
      if (controller != null)
         controller.clear();
   }

}