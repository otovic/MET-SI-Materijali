/***********************************************************************
 * Module:  AuthService.java
 * Author:  srdjan
 * Purpose: Defines the Interface AuthService
 ***********************************************************************/

package org.szvd.services;

import org.szvd.model.User;
import java.util.*;

/** @pdOid 26dee898-2fdc-4f96-8322-ecff5415c432 */
public interface AuthService {
   /** @param username 
    * @param password
    * @pdOid ce98b926-487c-4640-84f6-1c2e766d64bf */
   User login(java.lang.String username, java.lang.String password);
   /** @param user
    * @pdOid c887d836-3e8f-43ac-b4da-bdf4d99320b4 */
   void logout(User user);

}