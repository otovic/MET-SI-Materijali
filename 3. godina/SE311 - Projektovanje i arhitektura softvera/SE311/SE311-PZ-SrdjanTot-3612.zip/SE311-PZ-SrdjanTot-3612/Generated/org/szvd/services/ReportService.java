/***********************************************************************
 * Module:  ReportService.java
 * Author:  srdjan
 * Purpose: Defines the Interface ReportService
 ***********************************************************************/

package org.szvd.services;

import java.util.*;

/** @pdOid 9c75959b-5419-4b0a-9bb3-66287f6f8b8b */
public interface ReportService {
   /** @param report 
    * @param query
    * @pdOid 2b0cd209-5c87-45e8-adeb-abbdce901e2c */
   java.lang.String generate(int report, java.lang.String query);

}