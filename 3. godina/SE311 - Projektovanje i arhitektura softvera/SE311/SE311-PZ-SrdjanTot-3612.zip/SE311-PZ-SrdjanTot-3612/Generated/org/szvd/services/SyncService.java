/***********************************************************************
 * Module:  SyncService.java
 * Author:  srdjan
 * Purpose: Defines the Interface SyncService
 ***********************************************************************/

package org.szvd.services;

import java.util.*;

/** @pdOid f1b0d0d6-fe36-4ccf-953c-c7fb09884908 */
public interface SyncService {
   /** @pdOid 776b77c2-c972-4359-b408-662c5391c772 */
   void syncAll();
   /** @param number
    * @pdOid 234eda8f-3643-415b-be70-be4f1c15b72e */
   void syncDocument(java.lang.String number);

}