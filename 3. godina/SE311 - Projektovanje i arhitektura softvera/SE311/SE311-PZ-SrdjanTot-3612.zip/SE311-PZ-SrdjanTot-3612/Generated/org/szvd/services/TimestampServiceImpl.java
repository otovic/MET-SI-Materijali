/***********************************************************************
 * Module:  TimestampServiceImpl.java
 * Author:  srdjan
 * Purpose: Defines the Class TimestampServiceImpl
 ***********************************************************************/

package org.szvd.services;

import java.util.*;

/** @pdOid b98627af-221a-4a70-b8c8-cbbf35180b69 */
public class TimestampServiceImpl implements TimestampService {
   /** @param data 
    * @param timestamp
    * @pdOid 0e5628fe-c421-4572-a226-d067633e7821 */
   public byte[] stamp(byte[] data, byte[] timestamp) {
      // TODO: implement
      return null;
   }
   
   /** @param data
    * @pdOid eb0a8ee5-0dae-4770-aa35-b7237e0a9d38 */
   public java.lang.String verify(byte[] data) {
      // TODO: implement
      return null;
   }
   
   /** @pdOid 1121d0f5-198f-4dc0-bd55-deccde5510bc */
   public TimestampServiceImpl() {
      // TODO: implement
   }

}