/***********************************************************************
 * Module:  ArchiveView.java
 * Author:  srdjan
 * Purpose: Defines the Class ArchiveView
 ***********************************************************************/

package org.szvd.app;

import org.szvd.services.DocumentService;
import java.util.*;

/** @pdOid b7738c18-494a-4aff-aae5-8bef382103c2 */
public class ArchiveView extends View {
   /** @pdOid 24b0ff63-bf98-47b3-a6b0-b6e3a4f7aefc */
   private DocumentService documentService;
   
   /** @param documentService
    * @pdOid c76776d1-ec1c-49b3-a6b7-90e02f300212 */
   public ArchiveView(DocumentService documentService) {
      // TODO: implement
   }
   
   /** @pdOid 92c4fada-c18e-4601-915c-e95887765810 */
   public void showArchive() {
      // TODO: implement
   }

}