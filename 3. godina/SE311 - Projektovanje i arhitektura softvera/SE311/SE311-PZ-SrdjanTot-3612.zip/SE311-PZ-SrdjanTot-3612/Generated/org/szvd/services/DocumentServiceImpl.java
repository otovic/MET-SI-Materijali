/***********************************************************************
 * Module:  DocumentServiceImpl.java
 * Author:  srdjan
 * Purpose: Defines the Class DocumentServiceImpl
 ***********************************************************************/

package org.szvd.services;

import org.szvd.model.Document;
import java.util.*;

/** @pdOid c8ffbbf0-7e6a-474d-9d94-b2b416f6ea4d */
public class DocumentServiceImpl implements DocumentService {
   /** @pdOid d64f938d-02e6-4f53-8bbe-f4549932586a */
   private org.szvd.persistence.Repository repository;
   /** @pdOid 6d1d549d-6c54-419b-babe-b288c5697701 */
   private NotificationService notification;
   
   /** @param query
    * @pdOid e8692fb2-8c26-40c6-9e3c-c524d12bb514 */
   public java.util.List<org.szvd.model.Document> find(java.lang.String query) {
      // TODO: implement
      return null;
   }
   
   /** @param entity
    * @pdOid af07b715-58fa-4de5-94f2-f8332de46c61 */
   public Document save(Document entity) {
      // TODO: implement
      return null;
   }
   
   /** @param id
    * @pdOid 6eaa8077-bc9b-4fb5-88bf-56b5bc4e5c58 */
   public void delete(long id) {
      // TODO: implement
   }
   
   /** @param document
    * @pdOid 7d2ccf7d-064c-4347-9e52-abfcb8c16054 */
   public void accept(Document document) {
      // TODO: implement
   }
   
   /** @param document 
    * @param state
    * @pdOid 670fe989-b1ae-493d-943b-a557aa765241 */
   public void changeState(Document document, int state) {
      // TODO: implement
   }
   
   /** @param repository 
    * @param notification
    * @pdOid 0527c9d3-ffd3-43ed-8386-ea6c9291a4e3 */
   public DocumentServiceImpl(org.szvd.persistence.Repository repository, NotificationService notification) {
      // TODO: implement
   }

}