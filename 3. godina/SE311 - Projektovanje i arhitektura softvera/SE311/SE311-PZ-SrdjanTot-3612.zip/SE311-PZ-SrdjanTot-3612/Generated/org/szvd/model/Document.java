/***********************************************************************
 * Module:  Document.java
 * Author:  srdjan
 * Purpose: Defines the Class Document
 ***********************************************************************/

package org.szvd.model;

import java.util.*;

/** @pdOid 5ce964d6-7235-4de4-bdd9-41a3bc4141c1 */
public class Document extends Entity {
   /** @pdOid b6f77776-35bc-401d-a5f5-517737798eb9 */
   private java.lang.String number;
   /** @pdOid 6645bbd3-d0cd-4b75-88e1-5033022b5d0d */
   private java.util.Date created;
   /** @pdOid 3d0ddff6-8bd6-4283-8edb-1ea8b07a4010 */
   private User createdBy;
   /** @pdOid 16ee14d2-4886-4298-a6ef-4ad4bcf1d1f3 */
   private User workingOn;
   /** @pdOid 480754be-9301-40b5-b0c4-bfff336df2c6 */
   private int state;
   /** @pdOid 18e2d2a7-e373-4a8c-8cc6-854bc2230f1c */
   private java.util.List<java.lang.String> files;
   
   /** @pdRoleInfo migr=no name=User assc=association2 coll=java.util.Collection impl=java.util.HashSet mult=0..* type=Aggregation */
   public java.util.Collection<User> user;
   
   /** @pdOid 965417f5-ae74-4775-ab8b-d47bea6e2b8e */
   public java.lang.String getNumber() {
      return number;
   }
   
   /** @param newNumber
    * @pdOid 62db4821-350b-4b98-96b7-94c9dd3999cd */
   public void setNumber(java.lang.String newNumber) {
      number = newNumber;
   }
   
   /** @pdOid 89f4f8e1-6494-44fa-9811-9f6d6570a67f */
   public java.util.Date getCreated() {
      return created;
   }
   
   /** @param newCreated
    * @pdOid 5d165e5d-4c0e-4b90-8550-fa029c98764f */
   public void setCreated(java.util.Date newCreated) {
      created = newCreated;
   }
   
   /** @pdOid 7237ec35-55d3-4983-972b-87f7d4594473 */
   public User getCreatedBy() {
      return createdBy;
   }
   
   /** @param newCreatedBy
    * @pdOid b3404bb4-e347-4211-9eb5-933317e355b4 */
   public void setCreatedBy(User newCreatedBy) {
      createdBy = newCreatedBy;
   }
   
   /** @pdOid 7e3d022b-ef47-47a8-802d-8cc25d934dae */
   public User getWorkingOn() {
      return workingOn;
   }
   
   /** @param newWorkingOn
    * @pdOid 8aa437aa-6174-43d8-9e07-16fcf2620ebc */
   public void setWorkingOn(User newWorkingOn) {
      workingOn = newWorkingOn;
   }
   
   /** @pdOid 9e1842f0-7271-47ee-b8e8-acee0fe9b16d */
   public int getState() {
      return state;
   }
   
   /** @param newState
    * @pdOid f936a8e8-d656-42a5-9e82-8c512ac372c3 */
   public void setState(int newState) {
      state = newState;
   }
   
   /** @pdOid 4ebc4f9a-dddf-49f6-b555-076832c022d4 */
   public java.util.List<java.lang.String> getFiles() {
      return files;
   }
   
   /** @param newFiles
    * @pdOid 7749a4d5-24e7-4b52-a1eb-d5ee0b4c21fe */
   public void setFiles(java.util.List<java.lang.String> newFiles) {
      files = newFiles;
   }
   
   
   /** @pdGenerated default getter */
   public java.util.Collection<User> getUser() {
      if (user == null)
         user = new java.util.HashSet<User>();
      return user;
   }
   
   /** @pdGenerated default iterator getter */
   public java.util.Iterator getIteratorUser() {
      if (user == null)
         user = new java.util.HashSet<User>();
      return user.iterator();
   }
   
   /** @pdGenerated default setter
     * @param newUser */
   public void setUser(java.util.Collection<User> newUser) {
      removeAllUser();
      for (java.util.Iterator iter = newUser.iterator(); iter.hasNext();)
         addUser((User)iter.next());
   }
   
   /** @pdGenerated default add
     * @param newUser */
   public void addUser(User newUser) {
      if (newUser == null)
         return;
      if (this.user == null)
         this.user = new java.util.HashSet<User>();
      if (!this.user.contains(newUser))
         this.user.add(newUser);
   }
   
   /** @pdGenerated default remove
     * @param oldUser */
   public void removeUser(User oldUser) {
      if (oldUser == null)
         return;
      if (this.user != null)
         if (this.user.contains(oldUser))
            this.user.remove(oldUser);
   }
   
   /** @pdGenerated default removeAll */
   public void removeAllUser() {
      if (user != null)
         user.clear();
   }

}