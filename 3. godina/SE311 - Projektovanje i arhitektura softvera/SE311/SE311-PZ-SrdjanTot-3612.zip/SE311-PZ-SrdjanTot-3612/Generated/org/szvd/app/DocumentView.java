/***********************************************************************
 * Module:  DocumentView.java
 * Author:  srdjan
 * Purpose: Defines the Class DocumentView
 ***********************************************************************/

package org.szvd.app;

import org.szvd.services.DocumentService;
import org.szvd.model.Template;
import java.util.*;

/** @pdOid c92f8df5-67f5-4f7c-81bf-796d1942afc2 */
public class DocumentView extends View {
   /** @pdOid 51d7bc53-fa97-4a5d-b6ed-cb91b9ae4e20 */
   private DocumentService documentService;
   
   /** @param documentService
    * @pdOid dc85fa29-d3f1-45a9-bfcc-bd13309fa065 */
   public DocumentView(DocumentService documentService) {
      // TODO: implement
   }
   
   /** @pdOid fccf67b5-8b62-4bbf-89a3-bd6634866b68 */
   public void showSearch() {
      // TODO: implement
   }
   
   /** @pdOid a4dde975-c8c3-4d46-bc9f-dedf3995afe8 */
   public void showAdd() {
      // TODO: implement
   }
   
   /** @pdOid 72b4a487-a004-4cc3-83bf-69171d91d0c5 */
   public void showEdit() {
      // TODO: implement
   }
   
   /** @param template
    * @pdOid 5aed86a7-1c7c-49cb-8d17-5120222bd9c0 */
   public void fillTemplate(Template template) {
      // TODO: implement
   }

}