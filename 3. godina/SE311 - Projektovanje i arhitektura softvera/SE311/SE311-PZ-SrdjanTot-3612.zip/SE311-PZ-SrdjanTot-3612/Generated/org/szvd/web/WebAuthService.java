/***********************************************************************
 * Module:  WebAuthService.java
 * Author:  srdjan
 * Purpose: Defines the Class WebAuthService
 ***********************************************************************/

package org.szvd.web;

import java.util.*;

/** @pdOid f23e0d6f-1c11-4b14-b3a3-e8b3ad6a98b9 */
public class WebAuthService extends org.szvd.services.AbstractAuthService {
   /** @pdOid 35da993d-dfd5-4ff8-a32c-f3b27f355b30 */
   private javax.servlet.http.HttpSession session;
   
   /** @param repository 
    * @param session
    * @pdOid d3d7a7b0-e158-402a-8641-686ffd01b8ce */
   public WebAuthService(org.szvd.persistence.Repository repository, javax.servlet.http.HttpSession session) {
      // TODO: implement
   }

}