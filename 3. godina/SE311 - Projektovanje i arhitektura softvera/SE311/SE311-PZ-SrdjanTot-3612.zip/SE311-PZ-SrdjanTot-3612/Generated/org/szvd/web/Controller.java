/***********************************************************************
 * Module:  Controller.java
 * Author:  srdjan
 * Purpose: Defines the Class Controller
 ***********************************************************************/

package org.szvd.web;

import java.util.*;

/** @pdOid b9f8c4fb-55ff-4d48-9abc-40695360e5f1 */
public abstract class Controller {
   /** @param request
    * @pdOid 3bb926f2-1272-4f50-a280-b8144e8804f3 */
   public java.lang.String handleRequest(java.lang.String request) {
      // TODO: implement
      return null;
   }

}