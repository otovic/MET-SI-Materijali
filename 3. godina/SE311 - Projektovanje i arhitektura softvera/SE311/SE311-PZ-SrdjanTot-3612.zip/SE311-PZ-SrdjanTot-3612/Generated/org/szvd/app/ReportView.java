/***********************************************************************
 * Module:  ReportView.java
 * Author:  srdjan
 * Purpose: Defines the Class ReportView
 ***********************************************************************/

package org.szvd.app;

import org.szvd.services.ReportService;
import java.util.*;

/** @pdOid 2f020fde-64eb-4714-bd23-11b65b9d3b64 */
public class ReportView extends View {
   /** @pdOid ed832dde-7d57-4b99-bd69-21f72a291796 */
   private ReportService reportService;
   
   /** @param reportService
    * @pdOid 6a2e1329-3492-4a78-b185-27a80eba0363 */
   public ReportView(ReportService reportService) {
      // TODO: implement
   }
   
   /** @pdOid 4a84654c-4c84-4948-b66a-09dce7ae1c6e */
   public void showReport() {
      // TODO: implement
   }

}