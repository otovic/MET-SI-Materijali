/***********************************************************************
 * Module:  LoginView.java
 * Author:  srdjan
 * Purpose: Defines the Class LoginView
 ***********************************************************************/

package org.szvd.app;

import org.szvd.services.AuthService;
import java.util.*;

/** @pdOid 3052f3c9-d5de-49db-be5e-093c5f6a0a9c */
public class LoginView extends View {
   /** @pdOid 597f340c-ee8b-434f-a244-5ca20dd634b8 */
   private AuthService authService;
   
   /** @param authService
    * @pdOid 83e54a5b-caa1-4f84-aab1-47ea9b607fe9 */
   public LoginView(AuthService authService) {
      // TODO: implement
   }
   
   /** @pdOid 56a698ce-a585-476b-8ada-3f2603e4774c */
   public void showLogin() {
      // TODO: implement
   }
   
   /** @pdOid 1eae27d0-ec8d-4ea2-98c0-7ad34f2d7667 */
   public void showLogout() {
      // TODO: implement
   }

}