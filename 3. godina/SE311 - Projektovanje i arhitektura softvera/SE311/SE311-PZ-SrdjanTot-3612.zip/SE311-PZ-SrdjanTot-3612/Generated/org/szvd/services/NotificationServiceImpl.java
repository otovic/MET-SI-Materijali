/***********************************************************************
 * Module:  NotificationServiceImpl.java
 * Author:  srdjan
 * Purpose: Defines the Class NotificationServiceImpl
 ***********************************************************************/

package org.szvd.services;

import java.util.*;

/** @pdOid 808ddda1-2c8e-448f-9672-069817528fee */
public class NotificationServiceImpl implements NotificationService {
   /** @param email 
    * @param subject 
    * @param message 
    * @param files
    * @pdOid adf4253d-0efd-4660-9c91-6afd746d55f6 */
   public void sendEmail(java.lang.String email, java.lang.String subject, java.lang.String message, java.util.List<java.lang.String> files) {
      // TODO: implement
   }
   
   /** @param phoneNumber 
    * @param message
    * @pdOid 80134d73-cc73-458c-9b8d-5bc7062e9ba0 */
   public void sendSms(java.lang.String phoneNumber, java.lang.String message) {
      // TODO: implement
   }
   
   /** @pdOid a99a2636-0d46-4d1a-9512-3c6b9c4dbd1a */
   public NotificationServiceImpl() {
      // TODO: implement
   }

}