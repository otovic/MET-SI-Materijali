/***********************************************************************
 * Module:  Entity.java
 * Author:  srdjan
 * Purpose: Defines the Class Entity
 ***********************************************************************/

package org.szvd.model;

import java.util.*;

/** @pdOid d529244a-1579-460c-9c80-0a058364f101 */
public abstract class Entity {
   /** @pdOid 586ea633-f9cd-4aae-8a24-b2c2e7465a5c */
   private long id;
   
   /** @pdOid e99a50a4-3c8a-4e33-a6b9-6b97cf1fa884 */
   public long getId() {
      return id;
   }
   
   /** @param newId
    * @pdOid 54dc2c5b-94b1-4e25-a021-b1f1fee4761d */
   public void setId(long newId) {
      id = newId;
   }

}