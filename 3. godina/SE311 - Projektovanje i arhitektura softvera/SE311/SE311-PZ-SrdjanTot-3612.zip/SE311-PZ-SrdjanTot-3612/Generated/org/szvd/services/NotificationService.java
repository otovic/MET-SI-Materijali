/***********************************************************************
 * Module:  NotificationService.java
 * Author:  srdjan
 * Purpose: Defines the Interface NotificationService
 ***********************************************************************/

package org.szvd.services;

import java.util.*;

/** @pdOid a353e14b-8876-48ba-af55-27ea193792a1 */
public interface NotificationService {
   /** @param email 
    * @param subject 
    * @param message 
    * @param files
    * @pdOid 5a9ab0df-11e2-4ddd-ba95-d7452373e43b */
   void sendEmail(java.lang.String email, java.lang.String subject, java.lang.String message, java.util.List<java.lang.String> files);
   /** @param phoneNumber 
    * @param message
    * @pdOid ed3fe90e-646e-4282-bb77-11d549e454b8 */
   void sendSms(java.lang.String phoneNumber, java.lang.String message);

}