/***********************************************************************
 * Module:  UserAuthService.java
 * Author:  srdjan
 * Purpose: Defines the Class UserAuthService
 ***********************************************************************/

package org.szvd.app;

import org.szvd.model.User;
import java.util.*;

/** @pdOid 2be30402-3025-45b3-a382-c46a8bb7ecdb */
public class UserAuthService extends org.szvd.services.AbstractAuthService {
   /** @pdOid 9850d4c8-3fdb-4a53-bddb-057cbcc4fc38 */
   private User user;
   
   /** @param repository
    * @pdOid 3d87acbc-43dd-4337-99ad-e7466505210b */
   public UserAuthService(org.szvd.persistence.Repository repository) {
      // TODO: implement
   }

}