/***********************************************************************
 * Module:  AdministrationView.java
 * Author:  srdjan
 * Purpose: Defines the Class AdministrationView
 ***********************************************************************/

package org.szvd.app;

import java.util.*;

/** @pdOid 2dd29a07-c7e6-4ef9-af70-998f022e60d7 */
public class AdministrationView extends View {
   /** @pdOid ca2d0018-9959-4b6b-aaa3-fdccd18b466c */
   private org.szvd.persistence.Repository repository;
   
   /** @param repository
    * @pdOid 9fd02521-b827-478d-8506-2fbe3c91e4c2 */
   public AdministrationView(org.szvd.persistence.Repository repository) {
      // TODO: implement
   }
   
   /** @pdOid b13727f4-d0cb-4d90-9998-d69f22557f2e */
   public void showSearch() {
      // TODO: implement
   }
   
   /** @pdOid 607f3320-cc7c-4086-a85e-d78f80ac4fbd */
   public void showAdd() {
      // TODO: implement
   }
   
   /** @pdOid d959ab09-c62e-4bc3-912a-77567659b0a8 */
   public void showEdit() {
      // TODO: implement
   }

}