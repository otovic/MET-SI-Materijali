/***********************************************************************
 * Module:  ReportServiceImpl.java
 * Author:  srdjan
 * Purpose: Defines the Class ReportServiceImpl
 ***********************************************************************/

package org.szvd.services;

import java.util.*;

/** @pdOid 8eda585f-b920-4b25-b8e8-8d701273976d */
public class ReportServiceImpl implements ReportService {
   /** @pdOid 781ae587-4883-48bc-97cb-a069f632d7b7 */
   protected org.szvd.persistence.Repository repository;
   
   /** @param report 
    * @param query
    * @pdOid 2a3e6c1e-fc53-4ef0-afb3-16ba7ae2f538 */
   public java.lang.String generate(int report, java.lang.String query) {
      // TODO: implement
      return null;
   }
   
   /** @param repository
    * @pdOid fb4acb94-fb44-4db3-8f66-b3a743a943df */
   public ReportServiceImpl(org.szvd.persistence.Repository repository) {
      // TODO: implement
   }

}