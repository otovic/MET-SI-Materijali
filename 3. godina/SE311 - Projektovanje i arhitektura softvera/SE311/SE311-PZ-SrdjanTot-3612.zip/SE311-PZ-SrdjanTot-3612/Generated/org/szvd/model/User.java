/***********************************************************************
 * Module:  User.java
 * Author:  srdjan
 * Purpose: Defines the Class User
 ***********************************************************************/

package org.szvd.model;

import java.util.*;

/** @pdOid badee8d4-a7ba-49c4-8a36-09b834b8c184 */
public abstract class User extends Entity {
   /** @pdOid 87530dc5-7168-48f6-aad8-a39a51e111c6 */
   private java.lang.String username;
   /** @pdOid fbd3645a-00bf-40cf-a90e-4f88f4142955 */
   private java.lang.String password;
   /** @pdOid 93beaed3-e6a6-44b7-9442-fc01247908c4 */
   private java.lang.String role;
   /** @pdOid 0610969d-a40f-4e80-8ecf-fe5663bb107d */
   private java.lang.String enabled;
   /** @pdOid 424f48bf-c4ca-4b90-a1fb-34eb8f059ead */
   private java.lang.String locked;
   /** @pdOid a2c87c96-6627-4502-b9ad-c94eef4a05e9 */
   private java.lang.String name;
   /** @pdOid 023aa3bc-a55c-4093-ad26-711e28fec3bb */
   private java.lang.String email;
   /** @pdOid 1c7e0ef6-4920-4fe2-9873-cf83d41b2e72 */
   private java.lang.String phoneNumber;
   
   /** @pdOid fd198953-8bb0-42bc-8897-6018795b0c55 */
   public java.lang.String getUsername() {
      return username;
   }
   
   /** @param newUsername
    * @pdOid f1763eae-cd90-4db7-ab56-f3167d6618e1 */
   public void setUsername(java.lang.String newUsername) {
      username = newUsername;
   }
   
   /** @pdOid a8ee80ff-fec6-4429-83b6-05e819bf5e3d */
   public java.lang.String getPassword() {
      return password;
   }
   
   /** @param newPassword
    * @pdOid fc366e20-6467-410b-ae13-bd5b6fd442fd */
   public void setPassword(java.lang.String newPassword) {
      password = newPassword;
   }
   
   /** @pdOid e45a46ef-56d5-48fb-8991-5cc6f2406045 */
   public java.lang.String getRole() {
      return role;
   }
   
   /** @param newRole
    * @pdOid d0a1d1e0-69d0-4dc8-a99a-b287311f0cdd */
   public void setRole(java.lang.String newRole) {
      role = newRole;
   }
   
   /** @pdOid 8d073045-1bd2-4b9c-9f2a-ad7ae08b8ead */
   public java.lang.String getEnabled() {
      return enabled;
   }
   
   /** @param newEnabled
    * @pdOid c8ede921-1115-4a54-a296-49c17e056ab4 */
   public void setEnabled(java.lang.String newEnabled) {
      enabled = newEnabled;
   }
   
   /** @pdOid 5175f0b0-c953-41f4-b352-0eb372467ef0 */
   public java.lang.String getLocked() {
      return locked;
   }
   
   /** @param newLocked
    * @pdOid 03605e78-6df0-4c74-b157-75402d4cb297 */
   public void setLocked(java.lang.String newLocked) {
      locked = newLocked;
   }
   
   /** @pdOid 9e1e4e54-43a8-4b73-becb-59d4b80a451d */
   public java.lang.String getName() {
      return name;
   }
   
   /** @param newName
    * @pdOid 95df6beb-50dd-48b9-94bd-1a9d3128cf4e */
   public void setName(java.lang.String newName) {
      name = newName;
   }
   
   /** @pdOid ba53fb5b-9455-49ca-88c3-69a70db83925 */
   public java.lang.String getEmail() {
      return email;
   }
   
   /** @param newEmail
    * @pdOid 7ed15c65-f39d-4ef8-9779-b286c1b44bda */
   public void setEmail(java.lang.String newEmail) {
      email = newEmail;
   }
   
   /** @pdOid 0524f42d-ecdc-4402-bb41-f9ba018a87c5 */
   public java.lang.String getPhoneNumber() {
      return phoneNumber;
   }
   
   /** @param newPhoneNumber
    * @pdOid 2c0a7b94-cee8-43ac-a3f1-d77b4877772b */
   public void setPhoneNumber(java.lang.String newPhoneNumber) {
      phoneNumber = newPhoneNumber;
   }

}