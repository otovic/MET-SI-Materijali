/***********************************************************************
 * Module:  DocumentFileServiceImpl.java
 * Author:  srdjan
 * Purpose: Defines the Class DocumentFileServiceImpl
 ***********************************************************************/

package org.szvd.services;

import org.szvd.model.DocumentFile;
import java.util.*;

/** @pdOid e6b4cc58-93ed-40b2-8f55-9e8d1f19c352 */
public class DocumentFileServiceImpl implements DocumentFileService {
   /** @pdOid 15c562f0-a3e7-461f-a27c-406cef41d23b */
   private org.szvd.persistence.Repository repository;
   
   /** @param query
    * @pdOid fb4b7073-462b-4b9e-b0d0-8ff9285bda02 */
   public java.util.List<org.szvd.model.DocumentFile> find(java.lang.String query) {
      // TODO: implement
      return null;
   }
   
   /** @param entity
    * @pdOid 50c6da1d-e10d-45f3-a14f-43070dee40a0 */
   public DocumentFile save(DocumentFile entity) {
      // TODO: implement
      return null;
   }
   
   /** @param id
    * @pdOid 3c0f0089-8a1e-4e44-ac14-dbbfb05e1f5e */
   public void delete(long id) {
      // TODO: implement
   }
   
   /** @param documentFile 
    * @param documents
    * @pdOid e10d6758-86cc-4662-abf2-1c3b0d4ac433 */
   public void setDocuments(DocumentFile documentFile, java.util.List<org.szvd.model.Document> documents) {
      // TODO: implement
   }
   
   /** @param repository
    * @pdOid f6b2bb44-6598-4fc2-9ea1-490a100e76cf */
   public DocumentFileServiceImpl(org.szvd.persistence.Repository repository) {
      // TODO: implement
   }

}