/***********************************************************************
 * Module:  TimestampService.java
 * Author:  srdjan
 * Purpose: Defines the Interface TimestampService
 ***********************************************************************/

package org.szvd.services;

import java.util.*;

/** @pdOid 079388b6-2230-4b98-89ad-ae618db887d0 */
public interface TimestampService {
   /** @param data 
    * @param timestamp
    * @pdOid c695ef9e-73d4-4c4f-b7e8-31d37237a473 */
   byte[] stamp(byte[] data, byte[] timestamp);
   /** @param data
    * @pdOid a2b5283d-3f3b-4226-a31e-e8eb7194beca */
   java.lang.String verify(byte[] data);

}