/***********************************************************************
 * Module:  Citizen.java
 * Author:  srdjan
 * Purpose: Defines the Class Citizen
 ***********************************************************************/

package org.szvd.model;

import java.util.*;

/** @pdOid d7f499ff-b39b-48de-876d-35ccde37f6b4 */
public class Citizen extends User {
   /** @pdOid ef196ca0-f408-4a20-961e-74aadf7a6df4 */
   private java.lang.String address;
   /** @pdOid 38d74c1c-e86d-4652-8976-808d58d778ee */
   private java.lang.String city;
   /** @pdOid a9730cc3-24db-4287-9452-3ff18eab2cab */
   private java.lang.String zip;
   /** @pdOid d6574355-d3d0-43e9-b460-bf84bf4abe48 */
   private java.lang.String country;
   
   /** @pdOid 30d9e923-0e4e-4c99-ab33-cb5b56e6dc06 */
   public java.lang.String getAddress() {
      return address;
   }
   
   /** @param newAddress
    * @pdOid 93076270-21c8-4d07-892a-d7f0dcd1a3e7 */
   public void setAddress(java.lang.String newAddress) {
      address = newAddress;
   }
   
   /** @pdOid 73fe0acf-4a40-466c-b49a-7b725bd16d60 */
   public java.lang.String getCity() {
      return city;
   }
   
   /** @param newCity
    * @pdOid 45713a2b-f2db-4802-be23-17f0cf69bec9 */
   public void setCity(java.lang.String newCity) {
      city = newCity;
   }
   
   /** @pdOid a2933e5b-3ec2-42b8-9426-8650b12e4eaf */
   public java.lang.String getZip() {
      return zip;
   }
   
   /** @param newZip
    * @pdOid 28375d6d-57eb-4a09-9fa1-8edb7c7ccd4a */
   public void setZip(java.lang.String newZip) {
      zip = newZip;
   }
   
   /** @pdOid 6fd88954-9683-4e27-b183-a4eaeb3ea0b0 */
   public java.lang.String getCountry() {
      return country;
   }
   
   /** @param newCountry
    * @pdOid f7db0677-84a8-4e23-90b9-57c1f8938d54 */
   public void setCountry(java.lang.String newCountry) {
      country = newCountry;
   }

}