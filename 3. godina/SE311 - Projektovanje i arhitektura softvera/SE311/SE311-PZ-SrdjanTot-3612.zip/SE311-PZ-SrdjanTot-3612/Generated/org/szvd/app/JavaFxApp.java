/***********************************************************************
 * Module:  JavaFxApp.java
 * Author:  srdjan
 * Purpose: Defines the Class JavaFxApp
 ***********************************************************************/

package org.szvd.app;

import java.util.*;

/** @pdOid be95f771-66a4-43a7-964b-7d88426d890b */
public class JavaFxApp {
   /** @pdOid 74b95023-acf1-4779-9e4a-9d9678aa97f0 */
   private java.util.List<org.szvd.app.View> views;
   
   /** @pdRoleInfo migr=no name=View assc=association1 coll=java.util.Collection impl=java.util.HashSet mult=0..* type=Aggregation */
   public java.util.Collection<View> view;
   
   /** @pdOid 10653e20-ce06-4cb5-9424-cdca0b51142d */
   public JavaFxApp() {
      // TODO: implement
   }
   
   /** @param view
    * @pdOid 66a7c435-af05-47c4-b68a-150711a97f2b */
   public void register(View view) {
      // TODO: implement
   }
   
   /** @param title
    * @pdOid 5cd1d850-c6a2-4d8d-8020-a43cbf61023e */
   public static void navigate(java.lang.String title) {
      // TODO: implement
   }
   
   
   /** @pdGenerated default getter */
   public java.util.Collection<View> getView() {
      if (view == null)
         view = new java.util.HashSet<View>();
      return view;
   }
   
   /** @pdGenerated default iterator getter */
   public java.util.Iterator getIteratorView() {
      if (view == null)
         view = new java.util.HashSet<View>();
      return view.iterator();
   }
   
   /** @pdGenerated default setter
     * @param newView */
   public void setView(java.util.Collection<View> newView) {
      removeAllView();
      for (java.util.Iterator iter = newView.iterator(); iter.hasNext();)
         addView((View)iter.next());
   }
   
   /** @pdGenerated default add
     * @param newView */
   public void addView(View newView) {
      if (newView == null)
         return;
      if (this.view == null)
         this.view = new java.util.HashSet<View>();
      if (!this.view.contains(newView))
         this.view.add(newView);
   }
   
   /** @pdGenerated default remove
     * @param oldView */
   public void removeView(View oldView) {
      if (oldView == null)
         return;
      if (this.view != null)
         if (this.view.contains(oldView))
            this.view.remove(oldView);
   }
   
   /** @pdGenerated default removeAll */
   public void removeAllView() {
      if (view != null)
         view.clear();
   }

}