/***********************************************************************
 * Module:  TemplateRepository.java
 * Author:  srdjan
 * Purpose: Defines the Class TemplateRepository
 ***********************************************************************/

package org.szvd.persistence;

import java.util.*;

/** @pdOid 82d0ee99-82ed-4112-809a-60bc3d40864b */
public class TemplateRepository implements Repository {
   /** @pdOid 98d8fa4b-e2cc-4785-900c-ab7cc6bada7f */
   private java.lang.String templatePath;
   
   /** @param templatePath
    * @pdOid b06f96ef-4d34-4a4b-b316-80aa541d4dfb */
   public TemplateRepository(java.lang.String templatePath) {
      // TODO: implement
   }
   
   /** @param query
    * @pdOid 609ecfd4-d9a8-4c80-87d0-aab18709b1d7 */
   public java.util.List<org.szvd.model.Entity> find(java.lang.String query) {
      // TODO: implement
      return null;
   }
   
   /** @param entity
    * @pdOid 60727ca7-04c0-466c-909e-be009e6c8eca */
   public org.szvd.model.Entity save(org.szvd.model.Entity entity) {
      // TODO: implement
      return null;
   }
   
   /** @param id
    * @pdOid d81efaef-57b9-40e1-9658-6680411e808c */
   public void delete(long id) {
      // TODO: implement
   }

}