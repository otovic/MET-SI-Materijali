/***********************************************************************
 * Module:  Employee.java
 * Author:  srdjan
 * Purpose: Defines the Class Employee
 ***********************************************************************/

package org.szvd.model;

import java.util.*;

/** @pdOid a0a52983-bd57-4513-b7ae-6a732efe4d51 */
public class Employee extends User {
   /** @pdOid 60393cfa-18cc-48da-a90e-f2dee2fa938f */
   private java.lang.String workplace;
   /** @pdOid 17c634dc-cdc9-4818-b7fc-4dedb99d2b6e */
   private java.lang.String section;
   
   /** @pdOid c575f1b9-a645-48e1-8129-8728e0d81886 */
   public java.lang.String getWorkplace() {
      return workplace;
   }
   
   /** @param newWorkplace
    * @pdOid 9d572c95-a9be-435e-8f36-432657847a8c */
   public void setWorkplace(java.lang.String newWorkplace) {
      workplace = newWorkplace;
   }
   
   /** @pdOid 7c635e4f-70a8-4bc9-9984-5f1a9374147c */
   public java.lang.String getSection() {
      return section;
   }
   
   /** @param newSection
    * @pdOid ed05fec4-ca51-4068-9d6f-8244f36ef85a */
   public void setSection(java.lang.String newSection) {
      section = newSection;
   }

}