/***********************************************************************
 * Module:  SyncServiceImpl.java
 * Author:  srdjan
 * Purpose: Defines the Class SyncServiceImpl
 ***********************************************************************/

package org.szvd.services;

import java.util.*;

/** @pdOid ea8e9a47-8cd3-4b77-a772-979b0995cb87 */
public class SyncServiceImpl implements SyncService {
   /** @pdOid 743308ac-c67c-4bae-abf6-c6015938c245 */
   private DocumentService documentService;
   
   /** @pdOid e9fac3f8-d84a-4856-9d3b-44d7e2318332 */
   public void syncAll() {
      // TODO: implement
   }
   
   /** @param number
    * @pdOid e78a8fcf-3df1-44f4-8b5e-7c28cd5dc4e2 */
   public void syncDocument(java.lang.String number) {
      // TODO: implement
   }
   
   /** @param documentService
    * @pdOid aeb171ae-aad5-46c8-94a3-e681cee931a3 */
   public SyncServiceImpl(DocumentService documentService) {
      // TODO: implement
   }

}