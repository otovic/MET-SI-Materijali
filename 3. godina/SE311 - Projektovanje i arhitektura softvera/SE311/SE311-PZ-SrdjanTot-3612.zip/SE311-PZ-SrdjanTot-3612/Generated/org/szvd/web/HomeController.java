/***********************************************************************
 * Module:  HomeController.java
 * Author:  srdjan
 * Purpose: Defines the Class HomeController
 ***********************************************************************/

package org.szvd.web;

import java.util.*;

/** @pdOid 3f9447c9-e3f2-4ba8-b584-41002206530f */
public class HomeController extends Controller {
   /** @pdOid 3184f778-a67f-4fa0-b9f1-347e8e5930b1 */
   public HomeController() {
      // TODO: implement
   }

}