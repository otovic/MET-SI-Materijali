/***********************************************************************
 * Module:  DocumentService.java
 * Author:  srdjan
 * Purpose: Defines the Interface DocumentService
 ***********************************************************************/

package org.szvd.services;

import org.szvd.model.Document;
import java.util.*;

/** @pdOid c6ed2578-524d-4194-ac30-b841403f67ce */
public interface DocumentService {
   /** @param query
    * @pdOid 3e64ad26-32a2-4005-912f-2645860db7d9 */
   java.util.List<org.szvd.model.Document> find(java.lang.String query);
   /** @param entity
    * @pdOid b806ab96-278e-48fb-96b2-9dd18d2827f2 */
   Document save(Document entity);
   /** @param id
    * @pdOid 05899ef4-a197-4b12-8f97-1a822f71add2 */
   void delete(long id);
   /** @param document
    * @pdOid 182514af-ac4c-4523-9e5f-43570a5b8596 */
   void accept(Document document);
   /** @param document 
    * @param state
    * @pdOid 81d9a321-b895-440b-88bc-4d78a7b7aff8 */
   void changeState(Document document, int state);

}