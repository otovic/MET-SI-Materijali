/***********************************************************************
 * Module:  DocumentFileView.java
 * Author:  srdjan
 * Purpose: Defines the Class DocumentFileView
 ***********************************************************************/

package org.szvd.app;

import org.szvd.services.DocumentFileService;
import java.util.*;

/** @pdOid eb72cba7-016b-49ed-8a75-4332a5b7ec79 */
public class DocumentFileView extends View {
   /** @pdOid 297e973b-5003-4232-a43b-99595ee365ac */
   private DocumentFileService documentFileService;
   
   /** @pdOid 12db17e8-15f1-4ac9-9f39-be8188aa8044 */
   public void showSearch() {
      // TODO: implement
   }
   
   /** @pdOid b25aee48-357a-4ddd-a5d1-9da3f6a75376 */
   public void showAdd() {
      // TODO: implement
   }
   
   /** @pdOid d1a56172-827a-46f3-8585-b677d1f01879 */
   public void showEdit() {
      // TODO: implement
   }

}