/***********************************************************************
 * Module:  SignService.java
 * Author:  srdjan
 * Purpose: Defines the Interface SignService
 ***********************************************************************/

package org.szvd.services;

import java.util.*;

/** @pdOid d7d4f7b6-e30d-48d5-804e-d72963bbf443 */
public interface SignService {
   /** @param data 
    * @param certificate
    * @pdOid 51b30ab6-288f-4a57-b7d8-ad1b73016af5 */
   byte[] sign(byte[] data, byte[] certificate);
   /** @param data
    * @pdOid 2636f3ff-89a5-454f-b8a7-cd37def67cce */
   java.lang.String verify(byte[] data);

}