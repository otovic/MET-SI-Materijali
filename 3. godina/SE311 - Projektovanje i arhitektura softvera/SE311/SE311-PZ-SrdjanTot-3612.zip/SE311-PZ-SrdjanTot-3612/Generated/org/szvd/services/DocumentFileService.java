/***********************************************************************
 * Module:  DocumentFileService.java
 * Author:  srdjan
 * Purpose: Defines the Interface DocumentFileService
 ***********************************************************************/

package org.szvd.services;

import org.szvd.model.DocumentFile;
import java.util.*;

/** @pdOid a0da6f92-072e-4adf-ad8b-7669d5aaa46a */
public interface DocumentFileService {
   /** @param query
    * @pdOid c8fdb03b-672f-4913-ab44-516f3f2dd525 */
   java.util.List<org.szvd.model.DocumentFile> find(java.lang.String query);
   /** @param entity
    * @pdOid a4969065-be63-49b8-a7ad-bfb65defde71 */
   DocumentFile save(DocumentFile entity);
   /** @param id
    * @pdOid ca07c757-9bfc-4462-8f1a-af915cd471f9 */
   void delete(long id);
   /** @param documentFile 
    * @param documents
    * @pdOid 122c2b03-b774-45d1-b5ba-9060b07e1a9e */
   void setDocuments(DocumentFile documentFile, java.util.List<org.szvd.model.Document> documents);

}