/***********************************************************************
 * Module:  Template.java
 * Author:  srdjan
 * Purpose: Defines the Class Template
 ***********************************************************************/

package org.szvd.model;

import java.util.*;

/** @pdOid b4ed89e2-54ad-45d1-9571-a474d73dd399 */
public class Template extends Entity {
   /** @pdOid f41e9d4d-9e2a-467c-82dc-dbe5ad8efe7d */
   private java.lang.String name;
   /** @pdOid 2f03c9fa-baa7-40a7-ac5b-40143c64d839 */
   private java.util.List<java.lang.String> fields;
   /** @pdOid 4e99d700-4d9b-4acd-9bf9-922f61a58293 */
   private java.util.List<java.lang.String> files;
   
   /** @pdOid 205da0d2-a399-45b8-94c6-43379330c8df */
   public java.lang.String getName() {
      return name;
   }
   
   /** @param newName
    * @pdOid f8f73e74-0aa6-4c2e-b84a-1b347a054e6e */
   public void setName(java.lang.String newName) {
      name = newName;
   }
   
   /** @pdOid 1cdfec3e-27f9-40a1-adcd-4429b5d68816 */
   public java.util.List<java.lang.String> getFields() {
      return fields;
   }
   
   /** @param newFields
    * @pdOid 9f6d1fd5-f512-4e4c-9bac-a89f7d611495 */
   public void setFields(java.util.List<java.lang.String> newFields) {
      fields = newFields;
   }
   
   /** @pdOid 52c9f8a2-51d6-4a17-b849-ff4c01b95bcc */
   public java.util.List<java.lang.String> getFiles() {
      return files;
   }
   
   /** @param newFiles
    * @pdOid 69feda97-07e0-4e1d-a64e-0ee88d379f21 */
   public void setFiles(java.util.List<java.lang.String> newFiles) {
      files = newFiles;
   }

}