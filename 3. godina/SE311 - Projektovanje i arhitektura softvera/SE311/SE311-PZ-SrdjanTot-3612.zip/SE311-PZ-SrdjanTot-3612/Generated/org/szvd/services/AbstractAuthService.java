/***********************************************************************
 * Module:  AbstractAuthService.java
 * Author:  srdjan
 * Purpose: Defines the Class AbstractAuthService
 ***********************************************************************/

package org.szvd.services;

import org.szvd.model.User;
import java.util.*;

/** @pdOid 9ba16c85-016b-4857-a91a-d871c290dcd5 */
public class AbstractAuthService implements AuthService {
   /** @pdOid 3395aaaa-848b-47f6-abc4-8c0869155b44 */
   protected org.szvd.persistence.Repository repository;
   
   /** @param username 
    * @param password
    * @pdOid 9cb8ed51-7af5-430f-8ffd-869f959ff9e6 */
   public User login(java.lang.String username, java.lang.String password) {
      // TODO: implement
      return null;
   }
   
   /** @param user
    * @pdOid 76b4ed74-c09b-4899-b043-dbf5119de8a0 */
   public void logout(User user) {
      // TODO: implement
   }
   
   /** @param repository
    * @pdOid d0ed88ca-b0fc-4fa5-8c31-90ca888678e2 */
   public AbstractAuthService(org.szvd.persistence.Repository repository) {
      // TODO: implement
   }

}