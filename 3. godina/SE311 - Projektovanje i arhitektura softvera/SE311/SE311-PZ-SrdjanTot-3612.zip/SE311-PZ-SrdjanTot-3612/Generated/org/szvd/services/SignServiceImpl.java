/***********************************************************************
 * Module:  SignServiceImpl.java
 * Author:  srdjan
 * Purpose: Defines the Class SignServiceImpl
 ***********************************************************************/

package org.szvd.services;

import java.util.*;

/** @pdOid ff527dee-7681-49c6-b57a-d7d11d3eb0f6 */
public class SignServiceImpl implements SignService {
   /** @param data 
    * @param certificate
    * @pdOid 953a5ae6-6abc-40fd-ad75-c14b49686943 */
   public byte[] sign(byte[] data, byte[] certificate) {
      // TODO: implement
      return null;
   }
   
   /** @param data
    * @pdOid 8da5ced3-9b12-4874-9247-55dfdee9c8bc */
   public java.lang.String verify(byte[] data) {
      // TODO: implement
      return null;
   }
   
   /** @pdOid 3c656bff-e630-4b95-aabe-619d377b7df4 */
   public SignServiceImpl() {
      // TODO: implement
   }

}