/***********************************************************************
 * Module:  View.java
 * Author:  srdjan
 * Purpose: Defines the Class View
 ***********************************************************************/

package org.szvd.app;

import java.util.*;

/** @pdOid 5ad1fbc1-049b-4b63-82bc-4ee1c9fa4021 */
public abstract class View {
   /** @pdOid 7fcfe119-1762-4d06-afc9-f88abd521862 */
   private java.lang.String title;
   
   /** @param eventData
    * @pdOid 7c1cddec-f407-435c-9ae6-6930420aebeb */
   public void handleEvent(java.lang.Object eventData) {
      // TODO: implement
   }

}