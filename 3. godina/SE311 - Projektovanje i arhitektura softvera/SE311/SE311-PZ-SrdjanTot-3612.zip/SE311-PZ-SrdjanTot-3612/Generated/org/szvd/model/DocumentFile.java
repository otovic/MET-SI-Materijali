/***********************************************************************
 * Module:  DocumentFile.java
 * Author:  srdjan
 * Purpose: Defines the Class DocumentFile
 ***********************************************************************/

package org.szvd.model;

import java.util.*;

/** @pdOid 1f75337d-8d61-4a7f-92e9-0840356be999 */
public class DocumentFile extends Entity {
   /** @pdOid 76297461-228f-4ec5-bf6e-0cd8753002fc */
   private java.lang.String number;
   /** @pdOid 21813643-3a7e-4b90-ba06-dfa34daf8359 */
   private java.util.List<org.szvd.model.Document> documents;
   
   /** @pdRoleInfo migr=no name=Document assc=association1 coll=java.util.Collection impl=java.util.HashSet mult=0..* type=Aggregation */
   public java.util.Collection<Document> document;
   
   /** @pdOid ed2d19a3-e178-4313-8ed4-5a2c5887c003 */
   public java.lang.String getNumber() {
      return number;
   }
   
   /** @param newNumber
    * @pdOid a8df24ef-4b59-4472-9988-9df017fc08c4 */
   public void setNumber(java.lang.String newNumber) {
      number = newNumber;
   }
   
   /** @pdOid 130bc517-8e92-4c01-b348-ec484334c881 */
   public java.util.List<org.szvd.model.Document> getDocuments() {
      return documents;
   }
   
   /** @param newDocuments
    * @pdOid 48c4d0a8-aca0-477e-b547-27170e48c451 */
   public void setDocuments(java.util.List<org.szvd.model.Document> newDocuments) {
      documents = newDocuments;
   }
   
   
   /** @pdGenerated default getter */
   public java.util.Collection<Document> getDocument() {
      if (document == null)
         document = new java.util.HashSet<Document>();
      return document;
   }
   
   /** @pdGenerated default iterator getter */
   public java.util.Iterator getIteratorDocument() {
      if (document == null)
         document = new java.util.HashSet<Document>();
      return document.iterator();
   }
   
   /** @pdGenerated default setter
     * @param newDocument */
   public void setDocument(java.util.Collection<Document> newDocument) {
      removeAllDocument();
      for (java.util.Iterator iter = newDocument.iterator(); iter.hasNext();)
         addDocument((Document)iter.next());
   }
   
   /** @pdGenerated default add
     * @param newDocument */
   public void addDocument(Document newDocument) {
      if (newDocument == null)
         return;
      if (this.document == null)
         this.document = new java.util.HashSet<Document>();
      if (!this.document.contains(newDocument))
         this.document.add(newDocument);
   }
   
   /** @pdGenerated default remove
     * @param oldDocument */
   public void removeDocument(Document oldDocument) {
      if (oldDocument == null)
         return;
      if (this.document != null)
         if (this.document.contains(oldDocument))
            this.document.remove(oldDocument);
   }
   
   /** @pdGenerated default removeAll */
   public void removeAllDocument() {
      if (document != null)
         document.clear();
   }

}