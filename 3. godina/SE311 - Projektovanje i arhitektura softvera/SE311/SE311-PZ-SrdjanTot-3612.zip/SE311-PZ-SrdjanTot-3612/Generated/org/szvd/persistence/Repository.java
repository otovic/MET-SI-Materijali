/***********************************************************************
 * Module:  Repository.java
 * Author:  srdjan
 * Purpose: Defines the Interface Repository
 ***********************************************************************/

package org.szvd.persistence;

import java.util.*;

/** @pdOid 5d4ba93d-abcb-4873-a6b2-980ca05210c0 */
public interface Repository {
   /** @param query
    * @pdOid 69afb933-b0f0-4cef-8464-5ba270341b62 */
   java.util.List<org.szvd.model.Entity> find(java.lang.String query);
   /** @param entity
    * @pdOid 26d6ccb5-f00d-4c51-976a-6e3aacf024a3 */
   org.szvd.model.Entity save(org.szvd.model.Entity entity);
   /** @param id
    * @pdOid 027dc9ef-9e10-4dc0-b452-9ed42549e5a7 */
   void delete(long id);

}