/***********************************************************************
 * Module:  LoginController.java
 * Author:  srdjan
 * Purpose: Defines the Class LoginController
 ***********************************************************************/

package org.szvd.web;

import org.szvd.services.AuthService;
import java.util.*;

/** @pdOid d3b84575-f02e-43b4-88fb-2547016bb3cc */
public class LoginController extends Controller {
   /** @pdOid 94b54e78-4f8b-467d-9dd5-68dc960bc07a */
   private AuthService authService;
   
   /** @param authService
    * @pdOid 24700376-6bf5-4575-8875-3116b765649d */
   public LoginController(AuthService authService) {
      // TODO: implement
   }

}