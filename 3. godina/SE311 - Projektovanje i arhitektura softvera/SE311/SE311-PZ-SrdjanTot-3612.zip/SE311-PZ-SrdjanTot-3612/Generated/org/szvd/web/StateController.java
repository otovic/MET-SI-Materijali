/***********************************************************************
 * Module:  StateController.java
 * Author:  srdjan
 * Purpose: Defines the Class StateController
 ***********************************************************************/

package org.szvd.web;

import org.szvd.services.DocumentService;
import java.util.*;

/** @pdOid 64e23713-bdf4-405e-b275-1d55a0bdee2c */
public class StateController extends Controller {
   /** @pdOid 71b4f925-fb30-446b-adb9-3009dc11112c */
   private DocumentService documentService;
   
   /** @param documentService
    * @pdOid c4b5ee1b-0553-435d-b555-7f08d8e3794f */
   public StateController(DocumentService documentService) {
      // TODO: implement
   }

}