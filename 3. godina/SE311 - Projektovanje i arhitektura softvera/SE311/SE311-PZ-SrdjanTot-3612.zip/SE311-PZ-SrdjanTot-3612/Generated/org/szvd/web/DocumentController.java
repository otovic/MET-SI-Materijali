/***********************************************************************
 * Module:  DocumentController.java
 * Author:  srdjan
 * Purpose: Defines the Class DocumentController
 ***********************************************************************/

package org.szvd.web;

import org.szvd.services.DocumentService;
import org.szvd.services.SignService;
import org.szvd.services.TimestampService;
import java.util.*;

/** @pdOid 3031b0a3-a40e-43e7-9e82-23dc798a062d */
public class DocumentController extends Controller {
   /** @pdOid 01582cc1-6c59-4c21-9cae-d93f5129d252 */
   private DocumentService documentService;
   /** @pdOid 886d4491-eb8b-4f14-aad6-e032ab5c9b72 */
   private SignService signService;
   /** @pdOid 5b3c2c17-bf9d-4153-a150-23dd5af154c7 */
   private TimestampService timestampService;
   
   /** @param documentService 
    * @param signService 
    * @param timestampService
    * @pdOid bb095d36-3873-46fb-bc6c-4407c0b95ad1 */
   public DocumentController(DocumentService documentService, SignService signService, TimestampService timestampService) {
      // TODO: implement
   }

}