/***********************************************************************
 * Module:  DataRepository.java
 * Author:  srdjan
 * Purpose: Defines the Class DataRepository
 ***********************************************************************/

package org.szvd.persistence;

import java.util.*;

/** @pdOid 7ea4ec34-5c65-41ac-a46c-be3f90d8c953 */
public class DataRepository implements Repository {
   /** @pdOid 0ce1ed6d-eeac-464f-99e0-0e89622248b9 */
   private java.sql.Connection connection;
   
   /** @param connectionString
    * @pdOid c0cfa62f-8a62-4d81-88e0-0a32dc715a8f */
   public DataRepository(java.lang.String connectionString) {
      // TODO: implement
   }
   
   /** @param query
    * @pdOid 397c9cee-0af5-4a75-816c-d7663afcba78 */
   public java.util.List<org.szvd.model.Entity> find(java.lang.String query) {
      // TODO: implement
      return null;
   }
   
   /** @param entity
    * @pdOid a7a41194-487a-4522-9ac9-b83accf485a8 */
   public org.szvd.model.Entity save(org.szvd.model.Entity entity) {
      // TODO: implement
      return null;
   }
   
   /** @param id
    * @pdOid 3f3b2142-4f57-4bc1-b4ac-869e78e8dea6 */
   public void delete(long id) {
      // TODO: implement
   }

}