#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

bool Proveri(int K)
{
    while (K % 2 == 0)
        K /= 2;
    while (K % 3 == 0)
        K /= 3;
    while (K % 5 == 0)
        K /= 5;

    return K == 1;
}

int *formiraj(int A[], int M, int *dimenzija_C)
{
    int *C = (int *)malloc(M * sizeof(int));
    if (C == NULL)
    {
        printf("Nema dovoljno memorije.\n");
        exit(1);
    }

    int brojac_C = 0;
    for (int i = 0; i < M; i++)
    {
        if (Proveri(A[i]))
        {
            C[brojac_C++] = A[i];
        }
    }

    if (brojac_C < M)
    {
        int *temp = (int *)realloc(C, brojac_C * sizeof(int));
        if (temp == NULL)
        {
            free(C);
            printf("Nema dovoljno memorije prilikom realokacije.\n");
            exit(1);
        }
        C = temp;
    }

    *dimenzija_C = brojac_C;
    return C;
}

int main()
{
    int M;
    printf("Unesite broj M: ");
    scanf("%d", &M);

    if (M <= 0)
    {
        printf("'M' mora biti pozitivan broj.\n");
        return 1;
    }

    int A[M];
    srand((unsigned)time(NULL));
    for (int i = 0; i < M; i++)
    {
        A[i] = rand() % 1000 + 1;
    }

    int dimenzija_C;
    int *C = formiraj(A, M, &dimenzija_C);

    printf("Niz C: ");
    for (int i = 0; i < dimenzija_C; i++)
    {
        printf("%d ", C[i]);
    }
    printf("\n");

    free(C);

    return 0;
}
