#include <iostream>
#include <string>
#include <vector>
#include <stdexcept>

class ViseOd10KarakteraException
{
public:
    const char *what() const
    {
        return "String sadrzi vise od 10 karaktera.";
    }
};

std::string ZameniSamoglasnike(std::string tekst)
{
    const std::string samoglasnici = "aeiouAEIOU";
    for (size_t i = 0; i < tekst.length(); ++i)
    {
        if (samoglasnici.find(tekst[i]) != std::string::npos)
        {
            tekst.replace(i, 1, "**");
            i++;
        }
    }
    return tekst;
}

int main()
{
    int N;

    std::string linija;
    std::vector<std::string> linije;
    std::cout << "Unesite broj linija teksta: ";
    
    std::cin >> N;
    std::cin.ignore();

    std::string linijaSaNajviseZvezdica;
    int maxZvezdiceZaRedom = 0;

    try
    {
        for (int i = 0; i < N; ++i)
        {
            std::getline(std::cin, linija);
            std::string izmenjenTekst = ZameniSamoglasnike(linija);

            if (izmenjenTekst.length() > 10)
            {
                throw ViseOd10KarakteraException();
            }

            std::cout << izmenjenTekst << " (" << izmenjenTekst.length() << " karaktera)" << std::endl;

            int trenutnoZvezdicaZaRedom = 0;
            int trenutnoMaxZvezdicaZaRedom = 0;
            for (char c : izmenjenTekst)
            {
                if (c == '*')
                {
                    trenutnoZvezdicaZaRedom++;
                }
                else
                {
                    trenutnoZvezdicaZaRedom = 0;
                }
                if (trenutnoZvezdicaZaRedom > trenutnoMaxZvezdicaZaRedom)
                {
                    trenutnoMaxZvezdicaZaRedom = trenutnoZvezdicaZaRedom;
                }
            }

            if (trenutnoMaxZvezdicaZaRedom > maxZvezdiceZaRedom)
            {
                maxZvezdiceZaRedom = trenutnoMaxZvezdicaZaRedom;
                linijaSaNajviseZvezdica = izmenjenTekst;
            }
        }

        std::cout << "Linija sa najvise zvezdica za redom: " << linijaSaNajviseZvezdica << std::endl;
    }
    catch (const ViseOd10KarakteraException &e)
    {
        std::cerr << e.what() << std::endl;
        return 1;
    }

    return 0;
}
