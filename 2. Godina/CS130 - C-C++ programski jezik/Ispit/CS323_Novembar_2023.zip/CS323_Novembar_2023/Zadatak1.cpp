#include <iostream>
#include <fstream>
#include <list>
#include <memory>
#include <string>
#include <algorithm>

class PrehProizvod
{
protected:
    std::string ime;
    double cena;

public:
    PrehProizvod(const std::string &ime, double cena) : ime(ime), cena(cena) {}
    virtual ~PrehProizvod() {}

    virtual double Info() const = 0;

    bool operator==(const PrehProizvod &other) const
    {
        return ime == other.ime && cena == other.cena;
    }

    const std::string &getIme() const { return ime; }
};

class Meso : public PrehProizvod
{
    std::string tipMeso;

public:
    Meso(const std::string &ime,
         double cena,
         const std::string &tipMeso)
        : PrehProizvod(ime, cena), tipMeso(tipMeso) {}

    double Info() const override
    {
        double cenaSaPDV = cena * 1.05;
        std::cout << "Meso: " << ime << ", Cena sa PDV: " << cenaSaPDV << ", Tip mesa: " << tipMeso << std::endl;
        return cenaSaPDV;
    }
};

class Sok : public PrehProizvod
{
    std::string tipSoka;

public:
    Sok(const std::string &ime,
        double cena,
        const std::string &tipSoka)
        : PrehProizvod(ime, cena), tipSoka(tipSoka) {}

    double Info() const override
    {
        double cenaSaPDV = cena * 1.10;
        std::cout << "Sok: " << ime << ", Cena sa PDV: " << cenaSaPDV << ", Tip soka: " << tipSoka << std::endl;
        return cenaSaPDV;
    }
};

void ucitajProizvode(const std::string &nazivFajla,
                     std::list<std::shared_ptr<PrehProizvod>> &mesa,
                     std::list<std::shared_ptr<PrehProizvod>> &sokovi)
{
    std::ifstream file(nazivFajla);
    if (!file)
    {
        std::cerr << "Ne moze da se otvori fajl: " << nazivFajla << std::endl;
        exit(1);
    }

    int tip;
    std::string ime, tipProizvoda;
    double cena;

    while (file >> tip)
    {
        std::getline(file.ignore(), ime, ',');
        file >> cena;
        std::getline(file.ignore(), tipProizvoda);
        if (tip == 0)
        {
            mesa.push_back(std::make_shared<Meso>(ime, cena, tipProizvoda));
        }
        else if (tip == 1)
        {
            sokovi.push_back(std::make_shared<Sok>(ime, cena, tipProizvoda));
        }
    }
}

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        std::cerr << "Mora se dati kao argument fajl: " << argv[0] << " Zadatak1_Proizvodi.txt" << std::endl;
        return 1;
    }

    std::string nazivFajla = argv[1];
    std::list<std::shared_ptr<PrehProizvod>> listaMesa, listaSokova;

    ucitajProizvode(nazivFajla, listaMesa, listaSokova);

    Meso M1("Piletina", 150.00, "Pilece");

    auto it = std::find_if(listaMesa.begin(),
                           listaMesa.end(),
                           [&](const std::shared_ptr<PrehProizvod> &proizvod)
                           { return *proizvod == M1; });

    if (it != listaMesa.end())
    {
        std::cout << "Meso se nalazi u listi proizvoda od mesa." << std::endl;
    }
    else
    {
        std::cout << "Meso se ne nalazi u listi proizvoda od mesa." << std::endl;
    }

    std::cout << "\nCene sokova sa PDV-om:" << std::endl;

    for (const auto &sok : listaSokova)
    {
        sok->Info();
    }

    return 0;
}