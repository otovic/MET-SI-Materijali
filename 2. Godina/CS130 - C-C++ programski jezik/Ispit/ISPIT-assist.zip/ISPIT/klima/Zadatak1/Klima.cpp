#include "Klima.h"
#pragma once
Klima::Klima()
{
}

Klima::Klima(string n, string s, double c, int j) :Proizvod(n, s, c), jacina(j)
{
}

Klima::~Klima()
{
}

void Klima::setJacina(int jacina)
{
	this->jacina = jacina;
}

int Klima::getJacina()
{
	return jacina;
}

void Klima::info()
{

	cout << "Ime: " << ime << " Sifra: " << sifra << " Cena: " << cena << " Jacina: " << jacina << endl;
}

void Klima::unos()
{

	cout << "Unesite Ime proizvoda  ";
	std::getline(cin >> ws, this->ime);
	cout << "Unesite Sifru Proizvoda: ";
	cin >> this->sifra;
	cout << "Unesite Cenu proizvoda: ";
	cin >> this->cena;
	cout << "Unesite Jacinu klime: ";
	cin >> this->jacina;
}

