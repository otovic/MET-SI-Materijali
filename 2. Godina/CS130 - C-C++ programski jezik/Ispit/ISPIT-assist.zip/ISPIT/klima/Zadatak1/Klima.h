#include<iostream>
#include"Proizvod.h"
#include<vector>
#pragma once
class Klima :public Proizvod {

	int jacina;
public:

	Klima();
	Klima(string, string, double, int);
	~Klima();

	void setJacina(int jacina);
	int getJacina();

	void info();

	void unos();





};