#include<iostream>
#include<vector>
#include"Proizvod.h"
#pragma once
class Mobilni :public Proizvod {

	string marka;
	string model;

public:
	Mobilni();
	Mobilni(string, string, double, string, string);
	~Mobilni();

	void setMarka(string marka);
	string getMarka();
	void setModel(string model);
	string getModel();

	void info();
	void unos();
};