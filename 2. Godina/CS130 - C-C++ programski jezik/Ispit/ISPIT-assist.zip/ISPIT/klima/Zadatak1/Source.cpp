#include "Klima.h"
#include "Mobilni.h"
#include <stack>
#pragma once

void upisi(stack<Klima>& klime, stack<Mobilni>& telefoni);
void main() {

	Proizvod* k = new Klima("Klima se", "12KL23", 20000, 5);
	Proizvod* m = new Mobilni("Huawei", "33MB55", 30000, "P50", "Kinez");

	k->info();
	m->info();

	stack<Klima> klime;
	stack <Mobilni> telefoni;


	int n;
	cout << "Unesite koliko Klima zelite da upisete: ";
	cin >> n;
	if (n > 5) {
		n = 5;
	}

	Klima tempD;
	for (int i = 0; i < n; i++) {
		tempD.unos();
		klime.push(tempD);
	}

	cout << "Unesite koliko Telefona zelite da upisete: ";
	cin >> n;
	if (n > 5) {
		n = 5;
	}

	Mobilni tempM;
	for (int i = 0; i < n; i++) {
		tempM.unos();
		telefoni.push(tempM);
	}

	upisi(klime, telefoni);

}

void upisi(stack<Klima>& klime, stack<Mobilni>& telefoni) {

	ofstream fajl;
	fajl.open("Proizvodi.txt");

	while (!(klime.empty())) {
		if (klime.top().getJacina() > 14000) {
			fajl << 1 << "\n";
			fajl << klime.top().getIme() << " " << klime.top().getSifra() << " " << klime.top().getCena() << " " << klime.top().getJacina() << endl;
		}
		klime.pop();
	}

	while (!(telefoni.empty())) {
		if (telefoni.top().getMarka() == "Samsung") {
		fajl << 0 << "\n";
		fajl << telefoni.top().getIme() << " " << telefoni.top().getSifra() << " " << telefoni.top().getCena() << " " << telefoni.top().getMarka()<<" "<< telefoni.top().getModel() << endl;
		}
		telefoni.pop();
	fajl.close();
	}
	
}