#include "Mobilni.h"
#pragma once
Mobilni::Mobilni()
{
}

Mobilni::Mobilni(string i, string s, double c, string ma, string m) :Proizvod(i, s, c), marka(ma), model(m)
{
}

Mobilni::~Mobilni()
{
}

void Mobilni::setMarka(string marka)
{
	this->marka = marka;
}

string Mobilni::getMarka()
{
	return marka;
}

void Mobilni::setModel(string model)
{
	this->model = model;
}

string Mobilni::getModel()
{
	return model;
}

void Mobilni::info()
{
	cout << "Ime: " << ime  << " Sifra: " << sifra << " Cena: " << cena << " Marka: " << marka << " Model: " << model << endl;
}


void Mobilni::unos()
{
		cout << "Unesite Ime proizvoda  ";
		std::getline(cin >> ws, this->ime);
		cout << "Unesite Sifru Proizvoda: ";
		cin >> this->sifra;
		cout << "Unesite Cenu proizvoda: ";
		cin >> this->cena;
		cout << "Unesite Marku telefona: ";
		std::getline(cin >> ws, this->marka);
		cout << "Unesite Model telefona ";
		std::getline(cin >> ws, this->model);

}
