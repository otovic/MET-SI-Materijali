#include<iostream>
#include<string>
#include<fstream>
#pragma once

using namespace std;

class Proizvod {

protected:
	string ime;

	string sifra;
	double cena;

public:

	Proizvod();
	Proizvod(string, string, double);
	~Proizvod();

	void setIme(string ime);
	string getIme();
	void setSifra(string sifra);
	string getSifra();
	void setCena(double cena);
	double getCena();

	virtual void info() = 0;
	virtual void unos() = 0;

};