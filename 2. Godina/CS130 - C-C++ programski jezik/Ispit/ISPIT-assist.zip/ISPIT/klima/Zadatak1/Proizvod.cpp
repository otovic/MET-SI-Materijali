#include "Proizvod.h"
#pragma once
Proizvod::Proizvod()
{
}

Proizvod::Proizvod(string i, string s, double c) :ime(i), sifra(s), cena(c)
{
}

Proizvod::~Proizvod()
{
}

void Proizvod::setIme(string ime)
{
	this->ime = ime;
}

string Proizvod::getIme()
{
	return ime;
}


void Proizvod::setSifra(string sifra)
{
	this->sifra = sifra;
}

string Proizvod::getSifra()
{
	return sifra;
}

void Proizvod::setCena(double cena)
{
	this->cena = cena;
}

double Proizvod::getCena()
{
	return cena;
}


