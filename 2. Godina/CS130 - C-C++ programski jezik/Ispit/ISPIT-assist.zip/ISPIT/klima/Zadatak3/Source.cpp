#include <vector>
#include <stdio.h>
#include"StringNemaTekstException.h"
int brojPojavljivanja(string s, string word);
using namespace std;
void zamenaIispis(vector<string>& stringovi);
bool zameniRec(string& str, const string& promena, const string& zaPromenu);
void provera(vector<string> stringovi);
vector<string> unos(const int& n);

void main() {

	int n;
	cout << "Unesite koliko linija teksta zelite da unesete: ";
	cin >> n;
	vector<string> stringovi;

	stringovi = unos(n);

	provera(stringovi);

	zamenaIispis(stringovi);



}

void zamenaIispis(vector<string>& stringovi) {

	for (string& s : stringovi) {
		cout << "Tekst pre zamene: " << s << endl;
		zameniRec(s, "****", "omg");
		zameniRec(s, "****", "lol");
		zameniRec(s, "****", "rofl");
		zameniRec(s, "****", "llah");
		zameniRec(s, "****", "stfw");
		cout << "Tekst posle zamene: " << s << endl;
	}


}
vector<string> unos(const int& n) {

	vector<string> stringovi;
	string a;
	for (int i = 0; i < n; i++) {

		cout << "Unesite tekst:";

		std::getline(cin >> ws, a);

		if (a.length() >= 6) {
			stringovi.push_back(a);
		}
		a = "";

	}
	return stringovi;

}
void provera(vector<string> stringovi) {

	for (string s : stringovi) {

		cout<< "Broj pojavljivanja reci CS323: "<< brojPojavljivanja(s, "CS323")<<endl;


		try {
			if (s.find("CS323") != std::string::npos || s.find("CS323") != std::string::npos) {
			}
			else {
				cout << "String: " << s << " ";
				throw StringNemaTekst;
			}
		}
		catch (StringNemaTekstException e) {
			cout << e.what() << endl;
		}
	}
}

bool zameniRec(string& str, const string& from, const string& to) {
	size_t start_pos = 0;
	bool provera = false;
	while ((start_pos = str.find(to, start_pos)) != std::string::npos) {
		str.replace(start_pos, to.length(), from);
		start_pos += from.length();
		provera = true;
	}

	return provera;
}

int brojPojavljivanja(string str, string word)
{
	int count = 0;
	int strLen = str.length();
	int wordLen = word.length();
	int j;

	for (int i = 0; i <= strLen; i++)
	{
		for (j = 0; j < wordLen; j++)
		{
			if (str[i + j] != word[j])
			{
				break;
			}
		}
		if (j == wordLen)
		{
			count++;
		}
	}
	return count;
}