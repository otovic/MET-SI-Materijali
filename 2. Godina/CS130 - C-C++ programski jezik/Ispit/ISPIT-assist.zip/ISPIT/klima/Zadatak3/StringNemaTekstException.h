#include<iostream>
#include<string>

using namespace std;

class StringNemaTekstException {

public:

	const char* what() const throw() {
		return " <==== Ovaj string nema rec CS323";
	}
}StringNemaTekst;