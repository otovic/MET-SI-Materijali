﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
Korišćenjem programskog jezika C formirati niz A[] od N slučajno odabranih elemenata iz
intervala od -100 do 100. Napisati funkciju koja takav niz deli na dva niza: niz B[] sadrži negativne
a niz C[] pozitivne elemente. Kreirati nizove B i C korišćenjem dinamičkog alociranja memorije, a
kao argumente funkcije vratiti ova dva niza, kao i njihove dimenzije. Testirati rad funkcije u
glavnom programu. 10 poena.
*/
int* podela(int* niz, int n);

void main() {
	srand(time(0));

	int n;
	printf("Unesite koliko elementada zelite da sadrzi niz: ");
	scanf("%d", &n);

	int* A = calloc(n, sizeof(int));
	int temp;
	for (int i = 0; i < n; i++) {
		temp = rand() % 100 + 1;
		if (rand() % 2 == 0) {
			A[i] = temp * -1;
		}
		else {
			A[i] = temp;
		}
	}

	FILE* fptr;
	fptr=fopen("Zadatak2.txt", "w");
	if (fptr == NULL)
	{
		printf("Error!");
		exit(1);
	}

	int* pointeri = podela(A, n);

	int* B = pointeri[0];
	int* C = pointeri[1];
	int* brojNegativnih = pointeri[2];
	int* brojPozitivnih = pointeri[3];

	fprintf(fptr, "Dimenzija niza B = %d\n", *brojNegativnih);
	for (int i = 0; i < *brojNegativnih; i++) {
		fprintf(fptr,"%d ", B[i]);
	}
	fprintf(fptr, "\n");

	fprintf(fptr, "Dimenzija niza C = %d\n", *brojPozitivnih);
	for (int i = 0; i < *brojPozitivnih; i++) {
		fprintf(fptr, "%d ", C[i]);
	}

	free(brojPozitivnih);
	free(brojNegativnih);
	free(B);
	free(C);
	free(A);

}
int* podela(int* niz, int n) {
	int* brojPozitivnih = calloc(1, sizeof(int));
	int* brojNegativnih = calloc(1, sizeof(int));
	for (int i = 0; i < n; i++) {
		if (niz[i] > 0) {
			brojPozitivnih[0]++;
		}
	}

	*brojNegativnih = n - *brojPozitivnih;
	int* B = calloc(n - *brojPozitivnih, sizeof(int));
	int* C = calloc(*brojPozitivnih, sizeof(int));

	for (int i = 0, p = 0, ne = 0; i < n; i++) {
		if (niz[i] > 0) {
			C[p] = niz[i];
			p++;
		}
		else {
			B[ne] = niz[i];
			ne++;
		}
	}

	int* povratni[] = { B,C,brojNegativnih ,brojPozitivnih };
	return povratni;
}