#include "Proizvod.h"
#include "Prozor.h"
#include "Vrata.h"
#include <iostream>
#include <istream>
#include <fstream>
#include <vector>
#include <string>
#include <queue>
#include <deque>

using namespace std;

int main(int argc, char* argv[]) {

	/*Prozor p("prozor", 3, 2, Prozor::Tip::Alu);
	Prozor p1("prozor", 1, 1, Prozor::Tip::Drvo);
	Prozor p2("prozor", 1, 2, Prozor::Tip::PVC);
	//Vrata v("vrata", 2, 2, Vrata::Namena::sobna);
	//Vrata v1("vrata", 1, 2, Vrata::Namena::ulazna);

	p.info();
	p1.info();
	p2.info();

	//v.info();
	//v1.info();*/

	ifstream fin;
	fin.open(argv[1]);

	queue<Prozor> prozorRed;
	queue<Vrata> vrataRed;

	Prozor prozor1;
	Vrata vrata1;

	string obj;
	int x;
	int y;
	string e;

	string broj;
	while (getline(fin, broj)) {

		if (broj.compare("") == 0) {
			continue;
		}

		while (fin >> obj >> x >> y >> e) {


			Prozor::Tip tipProzor = Prozor::Tip::Alu;

			if (e.compare("PVC") == 0) {
				tipProzor = Prozor::Tip::PVC;

			}
			else if (e.compare("Alu") == 0) {
				tipProzor = Prozor::Tip::Alu;

			}
			else if (e.compare("Drvo") == 0) {
				tipProzor = Prozor::Tip::Drvo;
			}
			prozor1.setIme(obj);
			prozor1.setDimX(x);
			prozor1.setDimY(y);
			prozor1.setTip(tipProzor);

			Vrata::Namena namenaVrata = Vrata::Namena::sobnaVrata;

			if (e.compare("sobna") == 0) {
				namenaVrata = Vrata::Namena::sobnaVrata;

			}
			else if (e.compare("ulazna") == 0) {
				namenaVrata = Vrata::Namena::ulaznaVrata;
			}
			vrata1.setIme(obj);
			vrata1.setDimX(x);
			vrata1.setDimY(y);
			vrata1.setNamena(namenaVrata);

			if (broj.compare("0") == 0) {

				prozorRed.push(prozor1);
			}
			else if (broj.compare("1") == 0) {
				vrataRed.push(vrata1);
			}
			break;
		}
	}
	fin.close();

	cout << "Red sa prozorima iz fajla sadrzi: " << endl;
	while (!prozorRed.empty()) {
		cout << prozorRed.front();
		prozorRed.pop();
	}


	cout << "Red sa vratima iz fajla sadrzi:  " << endl;
	while (!vrataRed.empty()) {
		cout << vrataRed.front();
		vrataRed.pop();
	}

	Prozor p1("prozor", 100, 120, Prozor::Tip::Alu);
	
	for (int i = 0; i < prozorRed.size(); i++) { 
		if (p1 == prozorRed.front()) {
		cout << "Objekat P1 se nalazi u vektoru! " << endl;
		    prozorRed.pop();
		}
		
	}


	
	return 0;
}