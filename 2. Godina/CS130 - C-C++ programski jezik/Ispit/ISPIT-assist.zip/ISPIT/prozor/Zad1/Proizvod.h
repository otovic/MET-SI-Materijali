#pragma once
#include <iostream>
#include <string>

using namespace std;

class Proizvod
{
protected:
	string ime;
	int dimX;
	int dimY;

public:
	Proizvod();
	Proizvod(string ime, int dimX, int dimY);
	void setIme(string ime);
	void setDimX(int dimX);
	void setDimY(int dimY);

	virtual void info() = 0;

};


