#pragma once
#include "Proizvod.h"
#include <vector>
class Vrata :
    public Proizvod
{
public:

    enum class Namena
    {
        sobnaVrata = 120,
        ulaznaVrata = 180
    };

    Namena namena;
    void setNamena(Namena namena);
    Vrata();
    Vrata(string ime, int dimX, int dimY, Namena namena);
    void info();
    friend ostream& operator<<(ostream& out, const Vrata& v);

};



