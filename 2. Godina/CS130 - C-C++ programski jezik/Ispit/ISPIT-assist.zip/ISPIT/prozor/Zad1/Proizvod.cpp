#include "Proizvod.h"

Proizvod::Proizvod()
{
}

Proizvod::Proizvod(string ime, int dimX, int dimY)
{
	this->ime = ime;
	this->dimX = dimX;
	this->dimY = dimY;

}

void Proizvod::setIme(string ime)
{
	this->ime = ime;
}

void Proizvod::setDimX(int dimX)
{
	this->dimX = dimX;
}

void Proizvod::setDimY(int dimY)
{
	this->dimY = dimY;
}

