#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void formiraj(int* a, int** b, int** c, int* v1, int* v2, int v4) {
	int koren1 = 0;
	int koren2 = 0;
	int pomoc; 
	int pomoc1;

	for (int i = 0; i < v4; i++) {

		double koren = sqrt((double)a[i]); 
		pomoc = koren; 
		if (pomoc == koren) {  
			koren1++;
		}
	
	}

	for (int i = 0; i < v4; i++) {
		double koren5 = sqrt((double)a[i]);
		pomoc1 = koren5;
		if (pomoc1 != koren5) {
			koren2++;
		}
	}


	int* tempB = (int*)malloc(koren1 * sizeof(int));
	int iteratorb = 0;
	int* tempC = (int*)malloc(koren2 * sizeof(int));
	int iteratorc = 0;
	
	for (int i = 0; i < v4; i++) {
		double koren = sqrt((double)a[i]);
		pomoc = koren;
		if (pomoc == koren) {
			tempB[iteratorb] = a[i];
			iteratorb++;
		}
	}
	*b = tempB;

	
	for (int i = 0; i < v4; i++) {
		double koren6 = sqrt((double)a[i]);
		pomoc1 = koren6;
		if (pomoc1 != koren6) {
			tempC[iteratorc] = a[i];
			iteratorc++;
		}		
	}
	*c = tempC;

	*v1 = koren1;
	*v2 = koren2;

	
}

int main() {
	int* a; 
	int** b = NULL;
	int** c = NULL;
	
	time_t t;
	int max = 200;
	int min = 0;
	int v1;
	int v2;
	int v4;
	printf("Unesite velicinu niza A: ");
	scanf("%d", &v4);

	a = (int*)malloc(v4 * sizeof(int));

	srand((unsigned)time(&t));

	printf("A niz:\n");
	for (int i = 0; i < v4; i++) {
		a[i] = (rand() % (max + 1 - min) + min);
		printf("%d\n", a[i]);

	}

	formiraj(a, &b, &c, &v1, &v2, v4);
	
	printf("B niz:\n");
	for (int i = 0; i < v1; i++) {

		printf("%d\n", b[i]);

	}

	printf("C niz:\n");
	for (int i = 0; i < v2; i++) {

		printf("%d\n", c[i]);

	}

	return 0;
}