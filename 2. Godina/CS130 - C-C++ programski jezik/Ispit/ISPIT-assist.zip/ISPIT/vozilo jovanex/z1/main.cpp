#include <iostream>
#include "Vozilo.h"
#include <vector>
#include <iterator>
#include <fstream>
#include <string>
#include <list>

int main() {
	ifstream fin;
	fin.open("Jovalex.txt");
	list<Automobil> au1;
	list<Kamion> km1;
	int vrsta, brMotora, brSasije, brMestaTeret;
	Automobil auto1;
	Kamion kamion1;
	while (fin >> vrsta >> brMotora >> brSasije >> brMestaTeret) {
		if (vrsta == 0) {
			auto1.setBrMotora(brMotora);
			auto1.setBrSasije(brSasije);
			auto1.setBrMesta(brMestaTeret);
			au1.push_back(auto1);
		}
		else if (vrsta == 1) {
			kamion1.setBrMotora(brMotora);
			kamion1.setBrSasije(brSasije);
			kamion1.setMaxTeret(brMestaTeret);
			km1.push_back(kamion1);
		}
	}
	cout << "Jovalex vozila" << endl;
	for (Automobil a1 : au1)
	{
		a1.info();
	}

	for (Kamion k1 : km1)
	{
		k1.info();
	}
	cout << endl;

	vector<Automobil> au2;
	vector<Kamion> km2;
	ifstream fin2;
	fin2.open("StartMB.txt");
	while (fin2 >> vrsta >> brMotora >> brSasije >> brMestaTeret) {
		if (vrsta == 0) {
			auto1.setBrMotora(brMotora);
			auto1.setBrSasije(brSasije);
			auto1.setBrMesta(brMestaTeret);
			au2.push_back(auto1);
		}
		else if (vrsta == 1) {
			kamion1.setBrMotora(brMotora);
			kamion1.setBrSasije(brSasije);
			kamion1.setMaxTeret(brMestaTeret);
			km2.push_back(kamion1);
		}
	}
	cout << "StartMB vozila" << endl;
	for (Automobil a1 : au2)
	{
		a1.info();
	}

	for (Kamion k1 : km2)
	{
		k1.info();
	}
	cout << endl;

	return 0;
}