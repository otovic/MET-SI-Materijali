#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <math.h>

void countAmount(int A[], int m, int* countB, int* countC) {
	double dblVrednost = 0;
	int intVrednost = 0;
	for (int i = 0; i < m; i++) {
		dblVrednost = sqrt(A[i]);
		intVrednost = sqrt(A[i]);
		if (dblVrednost == intVrednost) {
			*countB = *countB + 1;
		}
		else {
			*countC = *countC + 1;
		}
	}
}

void formiraj(int A[], int* B, int* C, int m) {
	int ctrB = 0;
	int ctrC = 0;
	double dblVrednost = 0;
	int intVrednost = 0;

	for (int i = 0; i < m; i++) {
		dblVrednost = sqrt(A[i]);
		intVrednost = sqrt(A[i]);
		if (dblVrednost == intVrednost) {
			*(B + ctrB) = *(A + i);
			ctrB = ctrB + 1;
		}
		else {
			*(C + ctrC) = *(A + i);
			ctrC = ctrC + 1;
		}
	}
}

int main() {
	const int M = 20;
	srand(time(0));
	int A[20];
	printf("Niz A: ");
	for (int i = 0; i < M; i++)
	{
		A[i] = rand() % 200;
		printf("%d ", A[i]);
	}

	int countB = 0;
	int countC = 0;

	countAmount(A, M, &countB, &countC);
	int* B = malloc(sizeof(int) * countB + sizeof(int));
	int* C = malloc(sizeof(int) * countC + sizeof(int));

	formiraj(A, B, C, M);

	FILE* out;
	out = fopen("Zadatak2.txt", "w");
	int kolona = 0;

	fprintf(out, "Niz B: \n");
	for (int i = 0; i < countB; i++) {
		if (kolona == 5) {
			fprintf(out, "\n");
			kolona = 0;
		}
		printf("%d ", *(B + i));
		fprintf(out, "%5d", *(B + i));
		kolona++;
	}

	kolona = 0;

	fprintf(out, "\nNiz C: \n");
	for (int i = 0; i < countC; i++) {
		if (kolona == 5) {
			fprintf(out, "\n");
			kolona = 0;
		}
		printf("%d ", *(C + i));
		fprintf(out, "%5d", *(C + i));
		kolona++;
	}

	return 0;
}