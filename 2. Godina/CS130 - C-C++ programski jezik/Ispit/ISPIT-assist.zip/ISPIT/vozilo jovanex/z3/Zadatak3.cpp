#include <iostream>
#include <string>
using namespace std;

void izmeni(string str) {
	size_t pos = string::npos;
	string toReplace = "JABUKA";
	string toReplaceMalo = "jabuka";

	while ((pos = str.find(toReplace)) != string::npos)
	{
		str.replace(pos, toReplace.length(), "KRUSKA");
	}

	while ((pos = str.find(toReplaceMalo)) != string::npos)
	{
		str.replace(pos, toReplaceMalo.length(), "kruska");
	}

	cout << str << endl;
	cout << "Prva cetiri karaktera: " << str.substr(0, 4) << endl;
	cout << "Poslednjih sest karaktera: " << str.substr(str.length() - 6, 6) << endl << endl;
}


int main() {
	izmeni("JABUKA rec jabuka druga rec treca JABUKA");
	return 0;
}