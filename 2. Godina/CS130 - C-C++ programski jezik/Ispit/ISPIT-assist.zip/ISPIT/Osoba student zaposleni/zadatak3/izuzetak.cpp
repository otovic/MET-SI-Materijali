#include "izuzetak.h"
#include<iostream>
using namespace std;

void izuzetak::ViseOd20KarakteraIzuzetak(string s5)
{
	if (s5.size() > 20) {

		throw R"(ViseOd20KarakteraIzuzetak)";
	}

}
