#pragma once
#include "Osoba.h"
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

class Student : public Osoba
{

private:
	
	int index;

public:

	int getIndex() {
		return index;
	}
	void setIndex(int x) {
		this->index = x;
	}


	Student(string ime, string prezime, string adresa, int brojtelefona, int index) {
		this->ime = ime;
		this->prezime = prezime;
		this->adresa = adresa;
		this->brojtelefona = brojtelefona;
		this->index = index;
	}
	Student() {};

	void info() {
		cout << "Student" << endl;
		cout << "Ime: " << ime << endl;
		cout << "Prezime: " << prezime <<  endl;
		cout << "Broj telefona " << brojtelefona << endl;
		cout << "Index " << index << endl;
		
	}

	ostream& operator<<(ostream& out, const Student& v)
	{
		return cout << "Zaposleni:" << v.ime << ", " << v.prezime << ", " << v.adresa << ", " << v.brojtelefona << , ", " << v.index << ", "; " << endl;
	}

	
	


};

