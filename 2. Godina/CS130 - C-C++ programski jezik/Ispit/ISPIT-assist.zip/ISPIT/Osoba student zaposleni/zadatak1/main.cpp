#include <iostream>
#include <fstream>
#include <string>
#include <queue>
#include <vector>
#include <iterator>
#include "Student.h"
#include "Zaposleni.h"

using namespace std;

int main() {
	Student a;
	Zaposleni k;

	ifstream fin;
	fin.open("info.txt");
	if (!fin) {
		cerr << "Greska pri otvaranju fajla -> Fajl nije pronadjen! " << endl;
	}

	string broj;
	string x;
	string b;
	int c = 0;
	int d = 0;
	int e = 0;
	int saw = 0;

	deque<Student> studentvec;
	deque<Zaposleni> zaposlenivec;


	ostream_iterator<Student> outputp(cout, "");
	ostream_iterator<Zaposleni> outputv(cout, "");

	while (getline(fin, broj)) {            //cita fajl


		if (broj.compare("") == 0) {
			continue;
		}

		while (fin >> x >> b >> c >> d >>e) {

			if (broj.compare("0") == 0) {

				a.setIme(x);
				a.setPrezime(b);
				a.setAdresa(c);
				a.setBrojtelefona(d);
				a.setIndex(e);
				studentvec.push_back(a);


			}
			else if (broj.compare("1") == 0) {
				k.setIme(x);
				k.setPrezime(b);
				k.setAdresa(c);
				k.setBrojtelefona(d);
				k.setIdZaposlenog(e);
				zaposlenivec.push_back(a);
				
			}
			else {
				cout << "Objekat iz fajla ne pripada trazenim vektorima" << saw << endl;
			}
			break;
		}
	}
	int i;


	fin.close();


	}











}