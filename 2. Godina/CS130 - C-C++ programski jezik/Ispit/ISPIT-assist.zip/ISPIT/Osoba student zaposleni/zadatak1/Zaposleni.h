#pragma once
#include "Proizvod.h"
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

class Zaposleni : public Osoba
{
private:
	
	int idZaposlenog;

public:

	int getIdzaposlenog() {
		return idZaposlenog;
	}
	void setIdZaposlenog (int x) {
		this->idZaposlenog = x;
	}

	Zaposleni (string ime, string prezime, string adresa, int brojtelefona, int idZaposlenog) {
		this->ime = ime;
		this->prezime = prezime;
		this->adresa = adresa;
		this->brojtelefona = brojtelefona;
		this->idZaposlenog = idZaposlenog;
	}
	Zaposleni() {};

	void info() {
		cout << "Zaposleni" << endl;
		cout << "Ime: " << ime << endl;
		cout << "Prezime: " << prezime << endl;
		cout << "Broj telefona " << brojtelefona << endl;
		cout << "ID " << idZaposlenog << endl;

	}
		ostream& operator<<(ostream & out, const Zaposleni & v)
		{
			return cout << "Zaposleni:" << v.ime << ", " << v.prezime << ", " << v.adresa << ", " << v.brojtelefona <<, ", "<<v.idzaposlenog<<", ";" << endl;
		}

		
		}
