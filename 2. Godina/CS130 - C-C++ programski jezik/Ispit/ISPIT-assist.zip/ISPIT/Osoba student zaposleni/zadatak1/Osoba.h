#pragma once
#include <iostream>
#include <string>

using namespace std;

class Osoba 
{

public:

	string ime;
	string prezime;
	string adresa;
	int brojtelefona;
	
	string getIme() {
		return ime;
	}
	void setIme(string n) {
		this->ime = n;
	}
	string getPrezime() {
		return prezime;
	}
	void setPrezime(string c) {
		this->prezime = c;
	}
	string getAdresa() {
		return adresa;
	}
	void setAdresa(string c) {
		this->adresa = c;
	}
	int getBrojtelefona() {
		return brojtelefona;
	}
	void setBrojtelefona(int x) {
		this->brojtelefona = x;
	}
	
	

	virtual void info() = 0;

};
