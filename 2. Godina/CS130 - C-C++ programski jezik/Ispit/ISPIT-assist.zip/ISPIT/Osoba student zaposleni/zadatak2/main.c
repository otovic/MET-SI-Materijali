#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void formiraj(char[A], 
	

	


}

int main() {
	char A[];
}