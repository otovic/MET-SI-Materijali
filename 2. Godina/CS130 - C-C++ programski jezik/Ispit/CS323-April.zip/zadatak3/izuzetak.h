#pragma once
#include<iostream>
#include<iostream>
using namespace std;
class izuzetak
{
public:
	void ViseOd20KarakteraIzuzetak(string s5);
};

