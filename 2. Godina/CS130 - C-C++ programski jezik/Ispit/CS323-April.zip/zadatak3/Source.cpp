#include<string>
#include<iostream>
#include"Izuzetak.h"
#include<algorithm>
using namespace std;


int main() {

	string s1 = "filipa", s2 = "bamilos", s3 = "nikola", s4;
	string aba = "aba";





	s4 = s1 + s2 + s3;
	cout << s4 << "\n";


	if (s4.length() > 20) {
		throw new izuzetak();
	}

	if ((s1.find(aba) == string::npos) && (s2.find(aba) == string::npos) && (s3.find(aba) == string::npos)) {

		if (s4.find(aba) != string::npos) {
			cout << "s4 sadrzi aba\n";
		}
		else {
			cout << "s4 ne sadrzi aba\n";
		}
	}
	else {
		cout << "prva 3 stringa sadrze aba\n";
	}

	std::replace(s4.begin(), s4.end(), 'a', 'b');
	cout << s4;
}

