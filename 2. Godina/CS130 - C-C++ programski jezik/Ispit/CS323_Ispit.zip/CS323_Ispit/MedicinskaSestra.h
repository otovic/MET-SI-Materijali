#pragma once
#include "Zaposleni.h"

class MedicinskaSestra : public Zaposleni
{
	private:
		int smena;
	public:
		MedicinskaSestra();
		MedicinskaSestra(const std::string&, const std::string&, const int&);

		void setSmena(const int&);
		const int getSmena();

		void info() override;
};