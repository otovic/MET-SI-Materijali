#include <iostream>
#include <string>
#include <fstream>
#include <array>

std::array<std::string, 10> FormNizRecenica();

template<class E, size_t T>
void IspisNizaS(const std::array<E, T>&);

int main()
{
    std::array<std::string, 10> niz_stringova = FormNizRecenica();
    IspisNizaS(niz_stringova);
}

template<class E, size_t T>
void IspisNizaS(const std::array<E, T>& niz)
{
    std::fstream izlaz("izlaz.txt", std::ios::out); //Fajl gde ce se niz stringova upisivati
    int broj_recenica = 0;

    for(const auto& s : niz)
    {
        if (s == "")
            continue;
        broj_recenica++;
    }

    izlaz << "Broj recenica: " << broj_recenica << "\n\n";

    for (const auto& string : niz) { izlaz << string << std::endl; }

    izlaz.close();
}

std::array<std::string, 10> FormNizRecenica()
{
    std::fstream ulaz("ulaz.txt", std::ios::in); //objekat za citanje iz fajla
    std::string recenica;
    std::array<std::string, 10> niz_recenica;
    int n = 0;

    while(std::getline(ulaz, recenica, '.'))
    {
        //Ako naidje na karakter nove linije, zamenjuje ga razmakom (korisceno zbog recenice koja ide u dva reda)
        for (int c = 0; c < recenica.size(); c++)
            if (recenica[c] == '\n') { recenica[c] = ' '; }

        niz_recenica[n] = recenica + ".";
        n++;
    }

    //Ispisuje sve clanove niza. Korisceno radi testiranja
    /*for (const auto& s : niz_recenica)
        std::cout << s << std::endl;*/

    ulaz.close();
    return niz_recenica;
}