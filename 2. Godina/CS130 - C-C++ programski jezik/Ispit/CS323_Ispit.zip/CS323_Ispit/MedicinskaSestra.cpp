#include "MedicinskaSestra.h"

MedicinskaSestra::MedicinskaSestra() {}

MedicinskaSestra::MedicinskaSestra(const std::string& s1, const std::string& s2, const int& i) : Zaposleni(s1, s2), smena(i) {}

void MedicinskaSestra::setSmena(const int& shift) { this->smena = shift; }

const int MedicinskaSestra::getSmena() { return this->smena; }

void MedicinskaSestra::info()
{
	std::cout << "Podaci o medicinskoj sestri:\n";
	std::cout << "Ime: " << this->ime << std::endl;
	std::cout << "Prezime: " << this->prezime << std::endl;
	std::cout << "Smena: " << this->smena << ". \n";
}