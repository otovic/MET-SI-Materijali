#pragma once
#include <string>
#include <iostream> //Ovo ce mi trebati za podklase

class Zaposleni
{
	protected:
		std::string ime, prezime;
	public:
		Zaposleni();
		Zaposleni(const std::string&, const std::string&);

		void setIme(const std::string&);
		void setPrezime(const std::string&);
		const std::string getIme();
		const std::string getPrezime();

		virtual void info() = 0;
};