#pragma once
#include "Zaposleni.h"

class Lekar : public Zaposleni
{
	private:
		std::string fakultet;
	public:
		Lekar();
		Lekar(const std::string&, const std::string&, const std::string&);

		void setFakultet(const std::string&);
		const std::string getFakultet();

		void info() override;
};