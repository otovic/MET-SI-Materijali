#include <iostream>
#include <fstream>
#include <list>
#include "Zaposleni.h"
#include "Lekar.h"
#include "MedicinskaSestra.h"

void testiranjePolimorfizma();

int main()
{
	//testiranjePolimorfizma();

	std::fstream fajl("Zaposleni.txt", std::ios::in);
	int broj; //Promenljiva koja pretstavlja broj zaposlenog koji se cita iz fajla
	
	//Liste
	std::list<Lekar> lekari;
	std::list<MedicinskaSestra> medicinske_sestre;

	std::string ime, prezime, datum, fakultet;

	while(fajl >> broj >> ime >> prezime >> datum >> fakultet)
	{
		if(broj == 0)
		{
			Lekar dok(ime, prezime, fakultet);
			lekari.push_back(dok);
		}
		else
		{
			MedicinskaSestra nurse(ime, prezime, std::stoi(fakultet));
			medicinske_sestre.push_front(nurse);
		}
	}

	Lekar* O1 = new Lekar("Milan", "Pajic", "Medicinski");
	
	for(std::list<Lekar>::iterator it = lekari.begin(); it != lekari.end(); it++)
	{
		std::cout << it->getIme() << " " << it->getPrezime() << " " << it->getFakultet() << std::endl;

		if (O1->getIme() == it->getIme() && O1->getPrezime() == it->getPrezime() && O1->getFakultet() == it->getFakultet())
		{
			std::cout << "Lekar sa unetim podacima postoji u listi!\n";
			break;
		}
		else
		{
			std::cout << "Lekar sa unetim podacima ne postoji u listi!\n";
			break;
		}
	}
	
	delete O1;
	fajl.close();
}

void testiranjePolimorfizma()
{
	//OVO ISPOD RADI!

	Zaposleni* zaposleni = new Lekar("Marko", "Petrovic", "Bioloski fakultet"); //Polimorfizam
	zaposleni->info();
	delete zaposleni; //Oslobadja se memorija na koju pokazuje pokazivac 'zaposleni'

	zaposleni = new MedicinskaSestra("Milica", "Jovanovic", 3);
	zaposleni->info();
	delete zaposleni; //Oslobadjanje memorije
}