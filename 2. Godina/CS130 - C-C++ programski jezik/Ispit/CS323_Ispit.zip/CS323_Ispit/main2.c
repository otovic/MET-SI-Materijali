#include <stdio.h>
#include <stdlib.h>

int* formiraj(const int* A);

int main()
{
    int A[30];

    srand(time(0));

    for (int c = 0; c < 10; c++) { A[c] = rand() % 101; }
}

int* formiraj(const int* A)
{
    //Dinamicko alociranje
    int* B = (int*)calloc(10, sizeof(int));
    int* C = (int*)calloc(10, sizeof(int));

    for(int i = 0; i < sizeof(A) / sizeof(A[0]); i++)
    {
        //Ako je clan niza 'A' deljiv sa obe svoje cifre, on postaje clan niza 'B'
        if (A[i] % (A[i] % 10) == 0 && A[i] % (A[i] / 10) == 0) { B[i] = A[i]; }
        //U suprotnom, on postaje clan niza 'C'
        else { C[i] = A[i]; }
    }

    return B, C;
}