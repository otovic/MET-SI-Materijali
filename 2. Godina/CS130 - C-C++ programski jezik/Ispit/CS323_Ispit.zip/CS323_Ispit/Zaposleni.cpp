#include "Zaposleni.h"

Zaposleni::Zaposleni()
{
	this->ime = "";
	this->prezime = "";
}

Zaposleni::Zaposleni(const std::string& s1, const std::string& s2) : ime(s1), prezime(s2) {}

void Zaposleni::setIme(const std::string& name) { this->ime = name; }

void Zaposleni::setPrezime(const std::string& surname) { this->prezime = surname; }

const std::string Zaposleni::getIme() { return this->ime; }

const std::string Zaposleni::getPrezime() { return this->prezime; }