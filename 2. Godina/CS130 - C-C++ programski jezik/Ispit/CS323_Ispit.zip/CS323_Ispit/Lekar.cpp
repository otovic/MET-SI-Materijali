#include "Lekar.h"

Lekar::Lekar() {}

Lekar::Lekar(const std::string& s1, const std::string& s2, const std::string& s3) : Zaposleni(s1, s2), fakultet(s3) {}

void Lekar::setFakultet(const std::string& faculty) { this->fakultet = faculty; }

const std::string Lekar::getFakultet() { return this->fakultet; }

void Lekar::info()
{
	std::cout << "Podaci o lekaru:\n";
	std::cout << "Ime: " << this->ime << std::endl;
	std::cout << "Prezime: " << this->prezime << std::endl;
	std::cout << "Fakultet koji je zavrsio: " << this->fakultet << std::endl;
}