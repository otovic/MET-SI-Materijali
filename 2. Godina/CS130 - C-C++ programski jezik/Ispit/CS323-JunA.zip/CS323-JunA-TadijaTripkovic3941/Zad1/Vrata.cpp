#include "Vrata.h"

Vrata::Vrata(string ime, int dimX, int dimY, Namena namena) : Proizvod(ime, dimX, dimY)
{
	this->namena = namena;
}

Vrata::Vrata()
{
}

void Vrata::setNamena(Namena namena)
{
	this->namena = namena;
}

void Vrata::info()
{
	cout << "ime: " << ime << endl;;
	cout << "dim x: " << dimX << endl;
	cout << "dim y: " << dimY << endl;
	cout << "namena: ";
	if (namena == Namena::sobnaVrata) {
		cout << "sobna vrata" << endl;
	}
	else {
		cout << "ulazna vrata" << endl;
	};
	cout << "cena: " << dimX * dimY * static_cast<int>(namena) << endl;
}


ostream& operator<<(ostream& out, const Vrata& v)
{
	string namenatemp = "";
	if (v.namena == Vrata::Namena::sobnaVrata) {
		namenatemp = "sobnaVrata";
	}
	else if (v.namena == Vrata::Namena::ulaznaVrata) {
		namenatemp = "ulaznaVrata";
	}
	out << "Ime: " << v.ime << ", Dimenzija x: " << v.dimX << ", Dimenzija y: " << v.dimY << ", Namena: " << namenatemp << endl;
	return out;
}
