#pragma once
#include "Proizvod.h"
#include <vector>
class Prozor :
    public Proizvod
{

public:

    enum class Tip
    {
        Alu = 200,
        PVC = 150,
        Drvo = 100
    };

    Tip tip;
    void setTip(Tip tip);
    Prozor();
    Prozor(string ime, int dimX, int dimY, Tip tip);
    void info();
    friend bool operator== (Prozor const& p1, Prozor const& p2);
    friend ostream& operator<<(ostream& out, const Prozor& p);
};

