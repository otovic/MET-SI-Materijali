#include "Prozor.h"

#include <iostream>
#include <istream>
#include <fstream>


Prozor::Prozor(string ime, int dimX, int dimY, Tip tip) :Proizvod(ime, dimX, dimY)
{
	this->tip = tip;
}

Prozor::Prozor()
{

}

void Prozor::setTip(Tip tip)
{
	this->tip = tip;
}

void Prozor::info()
{

	cout << "ime: " << ime << endl;
	cout << "dim x: " << dimX << endl;
	cout << "dim y: " << dimY << endl;
	cout << "tip: ";

	if (tip == Tip::Alu) {
		cout << "Alu" << endl;
	}
	else if (tip == Tip::PVC) {
		cout << "PVC" << endl;;
	}
	else {
		cout << "Drvo" << endl;
	};
	cout << "cena: " << dimX * dimY * static_cast<int>(tip) << endl;

}

bool operator==(Prozor const& p1, Prozor const& p2)
{
	if (p1.ime == p2.ime && p1.dimX == p2.dimX && p1.dimY == p2.dimY && p1.tip == p2.tip ) {
		return true;
	}
	else {
		return false;
	}

}

ostream& operator<<(ostream& out, const Prozor& p)
{
	string namenatemp = "";
	if (p.tip == Prozor::Tip::Alu) {
		namenatemp = "Alu";
	}
	else if (p.tip == Prozor::Tip::PVC) {
		namenatemp = "PVC";
	}
	else if (p.tip == Prozor::Tip::Drvo) {
		namenatemp = "Drvo";
	}
	out << "Ime: " << p.ime << ", Dimenzija x: " << p.dimX << ", Dimenzija y: " << p.dimY << ", Tip: " << namenatemp << endl;
	return out;
}


