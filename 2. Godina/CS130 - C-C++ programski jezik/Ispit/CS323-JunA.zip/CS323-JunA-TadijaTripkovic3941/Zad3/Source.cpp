#include<string>
#include<iostream>


using namespace std;

void izmeni(string subject) {
	string search = "CS323";
	string replace = "C/C++";

	string a = "CS323";
	size_t found = subject.find(a);

	if (found != string::npos) {
	}
	else {
		throw "StringNemaTekst";
	}
	
	size_t pos = 0;
	int brojac = 0;
	while ((pos = subject.find(search, pos)) != std::string::npos) {

		subject.replace(pos, search.length(), replace);
		pos += replace.length();
		
	}
	cout << "Izmenjena recenica: " << subject << endl;

	string k1;
	string k2;
	k1 = subject.substr(0, 3);
	cout << "Prva 3 elementa:" << endl;
	cout << k1 << endl;
	k2 = subject.substr(subject.length() - 3, 3);
	cout << "Poslednja 3 elementa: " << endl;
	cout << k2 << endl;
}


int main() {
	

	
	try {

		while (1) {
			cout << "Unesite Vasu recenicu: " << endl;
			string subject;

			cin >> subject;

			izmeni(subject);
			
		}

		}
		catch (const char* msg) {
			cerr << msg << endl;
	    }


	



	return 0;
}