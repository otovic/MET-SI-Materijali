public class DrvoNoud {
    int value;
    DrvoNoud left, right;

    public DrvoNoud(int value) {
        this.value = value;
        left = null;
        right = null;
    }
}
