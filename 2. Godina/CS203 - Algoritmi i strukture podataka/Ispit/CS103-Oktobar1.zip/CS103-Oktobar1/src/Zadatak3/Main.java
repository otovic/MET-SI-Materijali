/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Zadatak3;

/**
 *
 * @author student
 */
public class Main {

    public static void main(String[] args) {
        System.out.println(count("Pe23235ra"));
    }

    public static int count(String str) {
        int count = 0;
        int index = str.length() - 1;
        return pomCount(str, index, count);
    }

    private static int pomCount(String str, int index, int count) {
        if (index < 0) {
            return count;
        } else if (!Character.isDigit(str.charAt(index))) {
            return pomCount(str, index - 1, count + 1); // Recursive call
        } else {
            return pomCount(str, index - 1, count); // Recursive call
        }
    }

}
