package Zadatak1;

import bst.BST;
import java.util.Scanner;

/**
 *
 * @author student
 */
public class MainKlasa {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Unesite int: ");
        int unetBroj = Integer.parseInt(sc.nextLine());
        BST<Integer> bst = new BST<>();
        bst.add(17);
        bst.add(29);
        bst.add(13);
        bst.add(11);
        bst.add(5); // LIST
        bst.add(14); // LIST
        bst.add(27); // LIST
        bst.add(30); // LIST
        System.out.println("Broj listova u stablu koji imaju vecu vrednost od unetog broja ("+unetBroj+"): ");
        System.out.println(bst.brojListova2(bst.root,unetBroj ));
        
    }
    
}
