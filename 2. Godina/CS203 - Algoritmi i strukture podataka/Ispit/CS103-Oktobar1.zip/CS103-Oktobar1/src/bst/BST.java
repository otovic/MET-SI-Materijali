/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bst;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author student
 */
public class BST<E extends Comparable<E>> implements Tree<E>, Cloneable {

    int size = 0;
    public TreeNode<E> root;
    Comparator<? super E> comparator = null;

    /**
     * Create an empty binary tree
     */
    public BST() {
    }


    public BST(Comparator<? super E> comparator) {
        this.comparator = comparator;
    }

    protected TreeNode<E> createNewNode(E e, TreeNode<E> parent) {
        TreeNode<E> node = new TreeNode<>(e);
        node.parent = parent;
        return node;
    }

    /**
     * Insert element e into the binary tree <br>
     * Return true if the element is inserted successfully
     */
    @Override
    public boolean insert(E e) {
        if (root == null) {
            root = createNewNode(e, null);
        } else {
            TreeNode<E> parent = null;
            TreeNode<E> curr = root;
            while (curr != null) {
                if (comparator != null) {
                    if (comparator.compare(e, curr.element) < 0) {
                        parent = curr;
                        curr = curr.left;
                    } else if (comparator.compare(e, curr.element) > 0) {
                        parent = curr;
                        curr = curr.right;
                    } else {
                        return false;
                    }
                } else {
                    if (e.compareTo(curr.element) < 0) {
                        parent = curr;
                        curr = curr.left;
                    } else if (e.compareTo(curr.element) > 0) {
                        parent = curr;
                        curr = curr.right;
                    } else {
                        return false;
                    }
                }
            }

            if (comparator != null) {
                if (comparator.compare(e, parent.element) < 0) {
                    parent.left = createNewNode(e, parent);
                } else {
                    parent.right = createNewNode(e, parent);
                }
            } else {
                if (e.compareTo(parent.element) < 0) {
                    parent.left = createNewNode(e, parent);
                } else {
                    parent.right = createNewNode(e, parent);
                }
            }
        }

        size++;
        return true;
    }

    /**
     * Return true if the element is in the tree
     */
    @Override
    public boolean search(E e) {
        TreeNode<E> curr = root;
        while (curr != null) {
            if (comparator != null) {
                if (comparator.compare(e, curr.element) < 0) {
                    curr = curr.left;
                } else if (comparator.compare(e, curr.element) > 0) {
                    curr = curr.right;
                } else {
                    return true;
                }
            } else {
                if (e.compareTo(curr.element) < 0) {
                    curr = curr.left;
                } else if (e.compareTo(curr.element) > 0) {
                    curr = curr.right;
                } else {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Delete an element from the binary tree <br>
     * Return true if the element is deleted successfully <br>
     * Return false if the element is not in the tree
     */
    @Override
    public boolean delete(E e) {
        TreeNode<E> parent = null;
        TreeNode<E> curr = root;
        while (curr != null) {
            if (comparator != null) {
                if (comparator.compare(e, curr.element) < 0) {
                    parent = curr;
                    curr = curr.left;
                } else if (comparator.compare(e, curr.element) > 0) {
                    parent = curr;
                    curr = curr.right;
                } else {
                    break;
                }
            } else {
                if (e.compareTo(curr.element) < 0) {
                    parent = curr;
                    curr = curr.left;
                } else if (e.compareTo(curr.element) > 0) {
                    parent = curr;
                    curr = curr.right;
                } else {
                    break;
                }
            }
        }

        if (curr == null) {
            return false;
        }

        if (curr.left == null) {
            if (parent == null) {
                root = curr.right;
                root.parent = null;
            } else {
                if (comparator != null) {
                    if (comparator.compare(e, parent.element) < 0) {
                        parent.left = curr.right;
                    } else {
                        parent.right = curr.right;
                    }
                } else {
                    if (e.compareTo(parent.element) < 0) {
                        parent.left = curr.right;
                    } else {
                        parent.right = curr.right;
                    }
                }
            }
        } else {
            TreeNode<E> parentOfRightmost = curr;
            TreeNode<E> rightmost = curr.left;

            while (rightmost.right != null) {
                parentOfRightmost = rightmost;
                rightmost = rightmost.right;
            }

            curr.element = rightmost.element;

            if (parentOfRightmost.right == rightmost) {
                parentOfRightmost.right = rightmost.left;
            } else {
                parentOfRightmost.left = rightmost.left;
            }
        }

        size--;
        return true;
    }

    /**
     * Returns a path from the root leading to the specified element
     */
    public ArrayList<TreeNode<E>> path(E e) {
        ArrayList<TreeNode<E>> list = new ArrayList<>();
        TreeNode<E> curr = root;

        while (curr != null) {
            list.add(curr);
            if (comparator != null) {
                if (comparator.compare(e, curr.element) < 0) {
                    curr = curr.left;
                } else if (comparator.compare(e, curr.element) > 0) {
                    curr = curr.right;
                } else {
                    break;
                }
            } else {
                if (e.compareTo(curr.element) < 0) {
                    curr = curr.left;
                } else if (e.compareTo(curr.element) > 0) {
                    curr = curr.right;
                } else {
                    break;
                }
            }
        }

        return list;
    }

    private void inorder(TreeNode<E> root) {
        if (root == null) {
            return;
        }
        inorder(root.left);
        System.out.print(root.element + " ");
        inorder(root.right);
    }

    @Override
    public void inorder() {
        inorder(root);
        System.out.println();
    }

    private void postorder(TreeNode<E> root) {
        if (root == null) {
            return;
        }
        postorder(root.left);
        postorder(root.right);
        System.out.print(root.element + " ");
    }

    @Override
    public void postorder() {
        postorder(root);
        System.out.println();
    }

    private void preorder(TreeNode<E> root) {
        if (root == null) {
            return;
        }
        System.out.print(root.element + " ");
        preorder(root.left);
        preorder(root.right);
    }

    @Override
    public void preorder() {
        preorder(root);
        System.out.println();
    }

    private TreeNode<E> getNode(E element) {
        TreeNode<E> current = root;

        while (current != null) {
            if (element.compareTo(current.element) < 0) {
                current = current.left;
            } else if (element.compareTo(current.element) > 0) {
                current = current.right;
            } else {
                break;
            }
        }

        if (current == null) {
            return null;
        }
        return current;
    }

    private void inorder2(TreeNode<E> root, int unetBroj, int count) {
        if (root == null) {
            return;
        }
        inorder2(root.left, unetBroj, count);
        Integer n = (Integer) root.element;
        if (isLeaf((E) n) && n.compareTo(unetBroj) > 0) {
            count++;
            System.out.println(root.element);
        }
        inorder2(root.right, unetBroj, count);
    }

    public void inorder2() {
        int count = 0;
        int unetBroj = Integer.parseInt(new Scanner(System.in).nextLine());
        System.out.println("-----");
        inorder2(root, unetBroj, count);
        System.out.println("count: " + count);
    }

    public boolean isLeaf(E element) {
        TreeNode<E> node = getNode(element);
        if (node == null) {
            return false;
        }
        return node.left == null && node.right == null;
    }

    public ArrayList<E> getPath(E e) {
        ArrayList<E> list = new ArrayList<>();
        TreeNode<E> node = getNode(e);
        while (node != null) {
            list.add(node.element);
            node = node.parent;
        }
        return list;
    }

    public <E extends Number> int zbir() {
        return zbir((TreeNode<E>) root);
    }

    private <E extends Number> int zbir(TreeNode<E> node) {
        if (node == null) {
            return 0;
        }
        return zbir(node.left) + node.element.intValue() + zbir(node.right);
    }

    public int brojElemenata() {
        return brojElemenata(root);
    }

    private int brojElemenata(TreeNode<E> node) {
        if (node == null) {
            return 0;
        }
        return brojElemenata(node.left) + 1 + brojElemenata(node.right);
    }

    /**
     * Get number of leaves
     */
    public int brojListova() {
        return brojListova(root);
    }

    private int brojListova(TreeNode<E> node) {
        if (node == null) {
            return 0;
        }
        if (node.left == null && node.right == null) {
            return 1;
        }
        return brojListova(node.left) + brojListova(node.right);
    }

    public int brojListova2(TreeNode<E> node, int unetBroj) {
        if (node == null) {
            return 0;
        }
        Integer n = (Integer) node.element;
        if (node.left == null && node.right == null && n.compareTo(unetBroj) > 0) {
            return 1;
        }
        return brojListova2(node.left, unetBroj) + brojListova2(node.right, unetBroj);
    }

    public boolean contains(E e) {
        return contains(root, e);
    }

    private boolean contains(TreeNode<E> node, E e) {
        if (node == null) {
            return false;
        }
        if (e.equals(node.element)) {
            return true;
        }
        if (e.compareTo(node.element) < 0) {
            return contains(node.left, e);
        } else if (e.compareTo(node.element) > 0) {
            return contains(node.right, e);
        } else {
            return false;
        }
    }

    /**
     * Visina, dubina, height, depth, broj nivoa
     */
    public int visina() {
        if (size == 1) {
            return 0;
        }
        return visina(root);
    }

    private int visina(TreeNode<E> node) {
        if (node == null) {
            return -1; // 0
        }
        return 1 + Math.max(visina(node.left), visina(node.right));
    }

    /**
     * Koliko elemenata ima na nivou k
     */
    public int brojElemenataNaNivou(int k) {
        return brojElemenataNaNivou(root, k, 1);
    }

    private int brojElemenataNaNivou(TreeNode<E> node, int k, int nivo) {
        if (node == null) {
            return 0;
        }
        if (nivo == k) {
            return 1;
        } else if (nivo < k) {
            return brojElemenataNaNivou(node.left, k, nivo + 1) + brojElemenataNaNivou(node.right, k, nivo + 1);
        } else {
            return 0;
        }
    }


    @Override
    public int getSize() {
        return size;
    }

    @Override
    public Iterator<E> iterator() {
        return null;
    }

    @Override
    public void clear() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
