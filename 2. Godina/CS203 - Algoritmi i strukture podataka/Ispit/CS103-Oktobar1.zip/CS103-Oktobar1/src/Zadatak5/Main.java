/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Zadatak5;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
public class Main {

    public static void main(String[] args) throws FileNotFoundException {

        List<String> lista = null;
        lista = new ArrayList<>();
        Scanner sc = null;
        sc = new Scanner(new File("FAJL_REGISTRACIJA.txt"));

        while (sc.hasNext()) {
            lista.add(sc.nextLine());
        }

        System.out.println("lista pre sortiranja: " + lista + "\n\n");

        quickSort(lista);
        System.out.println("nakon sortiranja: " + lista + "\n\n");

    }

    static <E extends Comparable<E>>
            void quickSort(List<E> arr, int start, int end) {
        if (start < end) {
            int pivotIndex = partition(arr, start, end);
            quickSort(arr, start, pivotIndex - 1);
            quickSort(arr, pivotIndex + 1, end);
        }
    }

    static <E extends Comparable<E>> int partition(List<E> arr, int start, int end) {
        int pivotIndex = pickPivotIndex(start, end);
        E pivot = arr.get(pivotIndex);
        swap(arr, pivotIndex, end);
        int index = start;
        for (int i = start; i < end; i++) {
            if (arr.get(i).compareTo(pivot) < 0) {
                swap(arr, i, index);
                index++;
            }
        }
        swap(arr, index, end);
        return index;
    }

    public static int pickPivotIndex(int start, int end) {
        return (int) (start + (end - start + 1) * Math.random());
    }

    static <E extends Comparable<E>> void quickSort(List<E> arr) {
        quickSort(arr, 0, arr.size() - 1);
    }

    public static <T extends Comparable<T>> void swap(List<T> arr, int i, int j) {
        T temp = arr.get(i);
        arr.set(i, arr.get(j));
        arr.set(j, temp);
    }
}
