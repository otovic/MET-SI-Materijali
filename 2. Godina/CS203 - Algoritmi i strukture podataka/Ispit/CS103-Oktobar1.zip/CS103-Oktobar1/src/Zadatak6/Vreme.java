
package Zadatak6;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author student
 */
public class Vreme {

    public static void main(String[] args) {
        Vreme d = new Vreme();
        d.m("15:44:22", d.tip1, d.tip2);
    }

    String tip1 = "^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$";
    String tip2 = "^(((([0-1][0-9])|(2[0-3])):?[0-5][0-9]:?[0-5][0-9]+$))";

    void m(String time, String r1, String r2) {
        Pattern pattern1 = Pattern.compile(r1);
        Matcher matcher1 = pattern1.matcher(time);
        boolean bool1 = matcher1.matches();
        
        Pattern pattern2 = Pattern.compile(r2);
        Matcher matcher2 = pattern2.matcher(time);
        boolean bool2 = matcher2.matches();
        if (bool1 || bool2) {
            System.out.println("Valid");
        } else {
            System.out.println("Not valid");
        }
    }
}
