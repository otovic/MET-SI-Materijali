/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z2;

/**
 *
 * @author student
 */
public class Main {

    public static void main(String[] args) {
        
        GrafList g1 = new GrafList(5);
        g1.addEdge(0, 1);
        g1.addEdge(3, 1);
        g1.addEdge(0, 4);
        g1.addEdge(4, 2);
        g1.addEdge(1, 2);
        g1.DFS(0); // pocinjem od 0-tog cvora
        
        System.out.println("-------");
        
        GrafList g2 = new GrafList(5);
        g2.addEdge(3, 4);
        g2.addEdge(1, 4);
        g2.addEdge(2, 4);
        g2.addEdge(0, 4);
        g2.addEdge(1, 2);
        g2.addEdge(3, 2);
        g2.DFS(3); // pocinjem od cvora 3
    }
}
