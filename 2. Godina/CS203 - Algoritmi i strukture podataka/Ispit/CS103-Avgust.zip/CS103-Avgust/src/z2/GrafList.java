/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z2;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

/**
 *
 * @author student
 */
public class GrafList {

    void DFS(int v) {
        Stack<Integer> stack = new Stack<>();
        boolean[] visited = new boolean[n];
        stack.push(v);

        int k = 0;
        while (!stack.empty()) {
            v = stack.pop();

            if (visited[v]) {
                continue;
            }

            visited[v] = true;
            System.out.print(v + "");
            System.out.println(", redni broj{" + k + "}");
            k++;

            List<Integer> list = adj.get(v);
            for (int i = list.size() - 1; i >= 0; i--) {
                int u = list.get(i);
                if (!visited[u]) {
                    stack.push(u);
                }
            }
        }
        System.out.println();
    }
    
    int n;
    List<List<Integer>> adj; // cvorovi

    GrafList(int n) {
        this.n = n;
        adj = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            adj.add(new LinkedList<Integer>()); // lista suseda za svaki cvor
        }
    }

    /**
     * (u)->(v)
     */
    void addEdge(int u, int v) {
        adj.get(u).add(v);
    }

    public void removeEdge(int i, int j) {
        java.util.Iterator<Integer> it = adj.get(i).iterator();
        while (it.hasNext()) {
            if (it.next() == j) {
                it.remove();
                break;
            }
        }
        java.util.Iterator<Integer> it2 = adj.get(j).iterator();
        while (it2.hasNext()) {
            if (it2.next() == i) {
                it2.remove();
                return;
            }
        }
    }

    public List<Integer> neighbours(int vertex) {
        return adj.get(vertex);
    }

    public void printGraph() {
        for (int i = 0; i < n; i++) {
            List<Integer> edges = neighbours(i);
            System.out.print(i + ": ");
            for (int j = 0; j < edges.size(); j++) {
                System.out.print(edges.get(j) + " ");
            }
            System.out.println();
        }
    }
}
