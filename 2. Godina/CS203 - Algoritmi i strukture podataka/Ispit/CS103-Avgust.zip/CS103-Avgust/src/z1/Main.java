/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z1;

/**
 *
 * @author student
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BST<Integer> bst = new BST<>();
        
        bst.insert(5);
        bst.insert(1);
        bst.insert(2);
        bst.insert(3);
        bst.insert(17);
        bst.insert(4);
        bst.insert(19);
        bst.insert(15);
        bst.insert(14);
        bst.insert(20);
        
        System.out.println(bst.zbirSadrzajaCvorovaKojiNisuListovi(bst.getRoot()));
    }
    
}
