/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Z1;

import Z5.Z5;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author MSI
 */
public class BST {

    protected TreeNode root;
    protected int size = 0;

    public BST() {
    }

    void search(int indeks) {
        TreeNode current = root;

        while (current != null) {
            if (indeks < current.element) {
                current = current.left;
            } else if (indeks > current.element) {
                current = current.right;
            } else {
                System.out.println(current.prOcena);
                break;
            }
        }
    }

    public boolean insert(int e, double prOcena) {
        if (root == null) {
            root = createNewNode(e, prOcena); // Create a new root
        } else {
            // Locate the parent node
            TreeNode parent = null;
            TreeNode current = root;
            while (current != null) {
                if (e < current.element) {
                    parent = current;
                    current = current.left;
                } else if (e > current.element) {
                    parent = current;
                    current = current.right;
                } else {
                    return false; // Duplicate node not inserted
                }
            }
            // Create the new node and attach it to the parent node
            if (e < parent.element) {
                parent.left = createNewNode(e, prOcena);
            } else {
                parent.right = createNewNode(e, prOcena);
            }
        }

        size++;
        return true; // Element inserted successfully
    }

    protected TreeNode createNewNode(int e, double prOcena) {
        return new TreeNode(e, prOcena);
    }

    
    private double max = 0;
    private TreeNode e;

    void inorder(TreeNode node) {
        if (node == null) {
            return;
        }
        inorder(node.left);
        if (max < node.prOcena) {
            max = node.prOcena;
            e = node;
        }
        inorder(node.right);
    }

    void studentSaNajvecomPrOcenom() {
        inorder(root);
        System.out.println(e.element);
    }

    void print(TreeNode node) {
        if (node == null) {
            return;
        }
        print(node.left);
        System.out.println(node.element + "->(prOcena):" + node.prOcena);
        print(node.right);
    }



    public BST toBst(List<Student> l) {
        BST rez = new BST();
        for (int i = 0; i < l.size(); i++) {
            rez.insert(l.get(i).indeks, l.get(i).prOcena);
        }
        return rez;
    }

    static ArrayList<Student> ucitaj() {
        ArrayList<Student> list = new ArrayList<>();
        Scanner sc = null;
        try {
            sc = new Scanner(new File("ulazBst.txt"));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Z5.class.getName()).log(Level.SEVERE, null, ex);
        }
        Student st;
        while (sc.hasNext()) {
            String next = sc.nextLine();
            //String[] split = next.split(" ");   // "\\s"
            /*for (int i = 0; i < split.length; i++) {
                list.add(split[i]);
            }*/
            //System.out.println(next);
            String[] split = next.split(" ");
            st = new Student(Integer.parseInt(split[0]), Integer.parseInt(split[1]));
            list.add(st);

        }
        return list;
    }

    public static class TreeNode {

        // indeks = element
        // prosecnaOcena = prOcena
        public int element;
        public TreeNode left;
        public TreeNode right;
        public double prOcena;

        public TreeNode(int e, double prOcena) {
            element = e;
            this.prOcena = prOcena;
        }

        @Override
        public String toString() {
            return "TreeNode{" + "element=" + element + ", prOcena=" + prOcena + '}';
        }
    }
}

class Student {

    int indeks, prOcena;

    public Student() {
    }

    public Student(int indeks, int prOcena) {
        this.indeks = indeks;
        this.prOcena = prOcena;
    }

    @Override
    public String toString() {
        return "Student{" + "indeks=" + indeks + ", prOcena=" + prOcena + '}';
    }


}
