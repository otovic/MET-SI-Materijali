/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Z1;

import static Z1.BST.ucitaj;

/**
 *
 * @author student
 */
public class Test {

    public static void main(String[] args) {
        BST bst = new BST();
        bst = bst.toBst(ucitaj());
        bst.print(bst.root);

        System.out.println("----\nProsecna ocena studenta sa indeksom 1111:");
        bst.search(1111); // get prOcenu studenta sa indeksom 1111

        System.out.println("----\nStudent s najvecom prosecnom ocenom:");
        bst.studentSaNajvecomPrOcenom();
    }
}
