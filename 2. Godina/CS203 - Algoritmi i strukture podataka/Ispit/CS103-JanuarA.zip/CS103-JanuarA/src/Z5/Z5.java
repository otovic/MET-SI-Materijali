/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Z5;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
public class Z5 {
    public static void main(String[] args) {
        Z5 z = new Z5();
        System.out.println("ulaz.txt:\n");
        for (String string : z.ucitaj()) {
            System.out.println(string);
        }
        System.out.println("----");
        System.out.println("izlaz.txt:\n");
        for (String string : z.sortirajIVrati()) {
            System.out.println(string);
        }
    }
    
    ArrayList<String> ucitaj() {
        ArrayList<String> list = new ArrayList<>();
        Scanner sc = null;
        try {
            sc = new Scanner(new File("ulaz.txt"));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Z5.class.getName()).log(Level.SEVERE, null, ex);
        }
        while (sc.hasNext()) {            
            String next = sc.nextLine();
           // System.out.println(next);
            list.add(next);
        }
        return list;
    }
    
    ArrayList<String> sortirajIVrati() {
        ArrayList<String> list = ucitaj();
        SelectionSort.selectionSort(list);
        return list;
    }
}
