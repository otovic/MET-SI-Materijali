package Z5;

import java.util.Comparator;
import java.util.List;

public class SelectionSort {

    // Time complexity: O(n^2) - Space complexity: O(1)
    public static void selectionSort(List<String> arr) {
        for (int i = 0; i < arr.size()- 1; i++) {
            int iMin = i;
            for (int j = i + 1; j < arr.size(); j++) {
                iMin = (comp.compare(arr.get(j), arr.get(iMin)) < 0) ? j : iMin;
            }
            swap(arr, i, iMin);
        }
    }

    private static void swap(List<String> arr, int i, int j) {
        String temp = arr.get(i);
        arr.set(i, arr.get(j));
        arr.set(j, temp);
    }    
    
    private static Comparator<String> comp = new Comparator<String>() {
        @Override
        public int compare(String t, String t1) {
            if (t1.length() > t.length()) {
                return 1;
            } else if (t.length() == t1.length()) {
                return 0;
            } else {
                return -1;
            }
        }        
    };

}
