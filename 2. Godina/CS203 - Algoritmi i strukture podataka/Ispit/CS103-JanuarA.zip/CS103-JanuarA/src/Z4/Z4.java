/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Z4;

/**
 *
 * @author student
 */
public class Z4 {

    public static void main(String[] args) {
        System.out.println(rek(2341)); //10
        System.out.println(rek(1111)); //4
        System.out.println(rek(12110)); //5
        System.out.println(rek(3111)); //6
        System.out.println(rek(765123422)); //32
    }
    
    public static boolean rek(int n) {
        return pomRek(n, 0) % 2 == 0;
    }

    private static int pomRek(int n, int sum) {
        if (n == 0) {
            return sum;
        } else {
            return pomRek(n / 10, sum + (int) (n % 10));
        }
    }
}
