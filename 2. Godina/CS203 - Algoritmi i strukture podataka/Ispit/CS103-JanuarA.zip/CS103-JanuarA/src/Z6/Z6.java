/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Z6;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author student
 */
public class Z6 {

    String tip = "(//.+$)|(/*.+\\*/$)";

    public static void main(String[] args) {
        Z6 o = new Z6();
        o.m("/*   komentar neki"
                + "SDSAD"
                + ""
                + "SD*/", o.tip);
        o.m("// komentar... komentar ", o.tip);
    }

    void m(String str, String regex) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        boolean bool = matcher.matches();
        if (bool) {
            System.out.println("Valid");
        } else {
            System.out.println("Not valid");
        }
    }
}

class Zadatak {

    public static void main(String[] args) {
        Z6 o = new Z6();
        String tekst
                = "//kraj\n/*metoda*/\n" +
"    public <E> void bezDuplikata(List<E> list) {\n" +
"        for (int i = 0; i < list.size(); i++) {\n" +
"            for (int j = i + 1; j < list.size(); j++) {\n" +
"                if (list.get(i).equals(list.get(j))) {\n" +
"                    list.remove(j);\n" +
"                    if (i != 0) {\n" +
"                        i--;\n" +
"                    }\n" +
"                }\n" +
"            }\n" +
"        }\n" +
"    } // kraj";
        String[] split = tekst.split("(//.+$)|(/*.+\\*/$)");
        String replaceAll = tekst.replaceAll("(//.+$)|(/*.+\\*/$)", "");
        //System.out.println(Arrays.toString(split));
        System.out.println(replaceAll);
    }
}
