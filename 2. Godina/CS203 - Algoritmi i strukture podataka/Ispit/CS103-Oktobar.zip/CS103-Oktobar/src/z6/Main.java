/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z6;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author student
 */
public class Main {

    public static void main(String[] args) {

        final String prvi = "(([0-1]?[0-9]|2[0-3]):[0-5][0-9])|((((([0-1][0-9])|(2[0-3])):?[0-5][0-9]:?[0-5][0-9]+$)))";

        Pattern pattern1 = Pattern.compile(prvi);

        String vreme1 = "12:24:24"; // 09:33
        if (pattern1.matcher(vreme1).matches()) {
            System.out.println(vreme1 + " = " + true);
        } else {
            System.out.println(false);
        }
    }
}
