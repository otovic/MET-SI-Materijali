/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z5;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
public class Main {

    public static void main(String[] args) {
        Main z = new Main();
        System.out.println("ulaz.txt:\n");
        for (String string : z.ucitaj()) {
            System.out.println(string);
        }
        System.out.println("----");
        System.out.println("SORTIRANO:");
        for (String string : z.sortirajIVrati()) {
            System.out.println(string);
        }
    }

    ArrayList<String> ucitaj() {
        ArrayList<String> list = new ArrayList<>();
        Scanner sc = null;
        try {
            sc = new Scanner(new File("ulaz.txt"));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        while (sc.hasNext()) {
            String next = sc.nextLine();
            // System.out.println(next);
            list.add(next);
        }
        return list;
    }

    ArrayList<String> sortirajIVrati() {
        ArrayList<String> list = ucitaj();
        QuickSortAlgoritam.quickSort(list);
        return list;
    }
}
