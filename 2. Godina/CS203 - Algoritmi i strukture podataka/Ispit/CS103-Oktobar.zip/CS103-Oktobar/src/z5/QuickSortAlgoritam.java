package z5;

import java.util.List;

public class QuickSortAlgoritam {

  // Time complexity: average O(n*log(n)) and worst O(n^2) - Space complexity: O(log(n))
  public static <T extends Comparable<T>> void quickSort(List<T> arr) {
    quickSort(arr, 0, arr.size() - 1);
  }

  private static <T extends Comparable<T>> void quickSort(List<T> arr, int start, int end) {
    if (start < end) {
      int pivotIndex = partition(arr, start, end);
      quickSort(arr, start, pivotIndex - 1);
      quickSort(arr, pivotIndex + 1, end);
    }
  }

  private static <T extends Comparable<T>> int partition(List<T> arr, int start, int end) {
    int pivotIndex = pickPivotIndex(start, end);
    T pivot = arr.get(pivotIndex);
    swap(arr, pivotIndex, end);
    int index = start;
    for (int i = start; i < end; i++) {
      if (arr.get(i).compareTo(pivot) < 0) {
        swap(arr, i, index);
        index++;
      }
    }
    swap(arr, index, end);
    return index;
  }

  public static int pickPivotIndex(int start, int end) {
    return (int) (start + (end - start + 1) * Math.random());
  }

  public static <T extends Comparable<T>> void swap(List<T> arr, int i, int j) {
    T temp = arr.get(i);
    arr.set(i, arr.get(j));
    arr.set(j, temp);
  }

}
