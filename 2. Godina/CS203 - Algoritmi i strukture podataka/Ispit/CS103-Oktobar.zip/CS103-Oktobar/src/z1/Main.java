package z1;

/**
 *
 * @author student
 */
public class Main {
    

    public static void main(String[] args) {
        z1.BST<Integer> binarnoStablo = new z1.BST<>();
        binarnoStablo.add(44);
        binarnoStablo.add(22);
        binarnoStablo.add(11);
        binarnoStablo.add(10);
        binarnoStablo.add(12);
        binarnoStablo.add(42);
        binarnoStablo.add(54);
        binarnoStablo.brojListova();
    }
    
}
