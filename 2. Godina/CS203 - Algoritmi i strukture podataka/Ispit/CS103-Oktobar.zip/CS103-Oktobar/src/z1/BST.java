/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author student
 */
public class BST<E extends Comparable<E>> implements Tree<E>, Cloneable {

    int size = 0;
    TreeNode<E> root;
    Comparator<? super E> comparator = null;

    /**
     * Create an empty binary tree
     */
    public BST() {
    }

    /**
     * Create a binary tree from an array
     */
    public BST(E[] niz) {
        for (int i = 0; i < niz.length; i++) {
            insert(niz[i]);
        }
    }

    /**
     * Create a binary tree from a collection
     */
    public BST(Collection<E> collection) {
        Iterator<E> iterator = collection.iterator();
        while (iterator.hasNext()) {
            insert(iterator.next());
        }
    }

    public BST(Comparator<? super E> comparator) {
        this.comparator = comparator;
    }

    protected TreeNode<E> createNewNode(E e, TreeNode<E> parent) {
        TreeNode<E> node = new TreeNode<>(e);
        node.parent = parent;
        return node;
    }

    /**
     * Insert element e into the binary tree <br>
     * Return true if the element is inserted successfully
     */
    @Override
    public boolean insert(E e) {
        if (root == null) {
            root = createNewNode(e, null);
        } else {
            TreeNode<E> parent = null;
            TreeNode<E> curr = root;
            while (curr != null) {
                if (comparator != null) {
                    if (comparator.compare(e, curr.element) < 0) {
                        parent = curr;
                        curr = curr.left;
                    } else if (comparator.compare(e, curr.element) > 0) {
                        parent = curr;
                        curr = curr.right;
                    } else {
                        return false;
                    }
                } else {
                    if (e.compareTo(curr.element) < 0) {
                        parent = curr;
                        curr = curr.left;
                    } else if (e.compareTo(curr.element) > 0) {
                        parent = curr;
                        curr = curr.right;
                    } else {
                        return false;
                    }
                }
            }

            if (comparator != null) {
                if (comparator.compare(e, parent.element) < 0) {
                    parent.left = createNewNode(e, parent);
                } else {
                    parent.right = createNewNode(e, parent);
                }
            } else {
                if (e.compareTo(parent.element) < 0) {
                    parent.left = createNewNode(e, parent);
                } else {
                    parent.right = createNewNode(e, parent);
                }
            }
        }

        size++;
        return true;
    }

    /**
     * Return true if the element is in the tree
     */
    @Override
    public boolean search(E e) {
        TreeNode<E> curr = root;
        while (curr != null) {
            if (comparator != null) {
                if (comparator.compare(e, curr.element) < 0) {
                    curr = curr.left;
                } else if (comparator.compare(e, curr.element) > 0) {
                    curr = curr.right;
                } else {
                    return true;
                }
            } else {
                if (e.compareTo(curr.element) < 0) {
                    curr = curr.left;
                } else if (e.compareTo(curr.element) > 0) {
                    curr = curr.right;
                } else {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Delete an element from the binary tree <br>
     * Return true if the element is deleted successfully <br>
     * Return false if the element is not in the tree
     */
    @Override
    public boolean delete(E e) {
        TreeNode<E> parent = null;
        TreeNode<E> curr = root;
        while (curr != null) {
            if (comparator != null) {
                if (comparator.compare(e, curr.element) < 0) {
                    parent = curr;
                    curr = curr.left;
                } else if (comparator.compare(e, curr.element) > 0) {
                    parent = curr;
                    curr = curr.right;
                } else {
                    break;
                }
            } else {
                if (e.compareTo(curr.element) < 0) {
                    parent = curr;
                    curr = curr.left;
                } else if (e.compareTo(curr.element) > 0) {
                    parent = curr;
                    curr = curr.right;
                } else {
                    break;
                }
            }
        }

        if (curr == null) {
            return false;
        }

        if (curr.left == null) {
            if (parent == null) {
                root = curr.right;
                root.parent = null;
            } else {
                if (comparator != null) {
                    if (comparator.compare(e, parent.element) < 0) {
                        parent.left = curr.right;
                    } else {
                        parent.right = curr.right;
                    }
                } else {
                    if (e.compareTo(parent.element) < 0) {
                        parent.left = curr.right;
                    } else {
                        parent.right = curr.right;
                    }
                }
            }
        } else {
            TreeNode<E> parentOfRightmost = curr;
            TreeNode<E> rightmost = curr.left;

            while (rightmost.right != null) {
                parentOfRightmost = rightmost;
                rightmost = rightmost.right;
            }

            curr.element = rightmost.element;

            if (parentOfRightmost.right == rightmost) {
                parentOfRightmost.right = rightmost.left;
            } else {
                parentOfRightmost.left = rightmost.left;
            }
        }

        size--;
        return true;
    }

    /**
     * Returns a path from the root leading to the specified element
     */
    public ArrayList<TreeNode<E>> path(E e) {
        ArrayList<TreeNode<E>> list = new ArrayList<>();
        TreeNode<E> curr = root;

        while (curr != null) {
            list.add(curr);
            if (comparator != null) {
                if (comparator.compare(e, curr.element) < 0) {
                    curr = curr.left;
                } else if (comparator.compare(e, curr.element) > 0) {
                    curr = curr.right;
                } else {
                    break;
                }
            } else {
                if (e.compareTo(curr.element) < 0) {
                    curr = curr.left;
                } else if (e.compareTo(curr.element) > 0) {
                    curr = curr.right;
                } else {
                    break;
                }
            }
        }

        return list;
    }

    private void inorder(TreeNode<E> root) {
        if (root == null) {
            return;
        }
        inorder(root.left);
        System.out.print(root.element + " ");
        inorder(root.right);
    }

    @Override
    public void inorder() {
        inorder(root);
        System.out.println();
    }

    private void postorder(TreeNode<E> root) {
        if (root == null) {
            return;
        }
        postorder(root.left);
        postorder(root.right);
        System.out.print(root.element + " ");
    }

    @Override
    public void postorder() {
        postorder(root);
        System.out.println();
    }

    private void preorder(TreeNode<E> root) {
        if (root == null) {
            return;
        }
        System.out.print(root.element + " ");
        preorder(root.left);
        preorder(root.right);
    }

    @Override
    public void preorder() {
        preorder(root);
        System.out.println();
    }
    /**
     * Get number of leaves
     */
    public void brojListova() {
        System.out.println("Broj za proveru: ");
        int brojSaUlaza = Integer.parseInt(new Scanner(System.in).nextLine());
        System.out.println("Broj listova vecih od datog broja = ");
        System.out.print(numberOfLeaves(root, brojSaUlaza) + "\n\n");
    }
    

    private int numberOfLeaves(TreeNode<E> node, int brojSaUlaza) {
        if (node == null) {
            return 0;
        }
        // poredjenje
        boolean tacnost = node.element.compareTo((E) Integer.valueOf(brojSaUlaza)) > 0;
        //

        if (node.right == null
                && node.left == null && tacnost) {
            return 1;
        }
        return numberOfLeaves(node.right, brojSaUlaza) 
                + numberOfLeaves(node.left, brojSaUlaza);
    }   

    @Override
    public int getSize() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Iterator<E> iterator() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void clear() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
