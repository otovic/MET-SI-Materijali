package z4;

/**
 *
 * @author student
 */
public class Main {
    public static void main(String[] args) {
        System.out.println(zajednickiPrefiks("prolaz", "program"));
    }
    static String zajednickiPrefiks(String T, String S) {
        int velicinaNajmanjeReci = Math.min(T.length(), S.length());
        for (int i = 0; i < velicinaNajmanjeReci; i++) {
            if (T.charAt(i) != S.charAt(i)) {
                return T.substring(0, i);
            }
        }
//        return s1.substring(0, velicinaNajmanjeReci);
        return "";
    }
}
