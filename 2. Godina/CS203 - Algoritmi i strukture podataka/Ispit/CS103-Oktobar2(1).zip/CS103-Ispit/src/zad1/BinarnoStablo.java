/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zad1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Queue;
import java.util.Stack;

/**
 *
 * @author student
 */
public class BinarnoStablo<E extends Comparable<E>> implements Tree<E>, Cloneable {

    public <E extends Number> boolean metod() {
        E element = (E) root.element;
        System.out.println("Element: " + element);
        System.out.println("Pri deljenju " + zbirSadrzajaCvorovaKojiSuListovi(root)+ " : " + element.doubleValue());
        return zbirSadrzajaCvorovaKojiSuListovi(root) % element.doubleValue() == 0;
    }

    private <E extends Number> int zbirSadrzajaCvorovaKojiSuListovi(TreeNode cvor) {
        int suma = 0;
        if (cvor == null) {
            return 0;
        }
        if (cvor.left == null && cvor.right == null) {
            E element = (E) cvor.element;
            suma += element.doubleValue();
        }
        return suma + zbirSadrzajaCvorovaKojiSuListovi(cvor.right) + zbirSadrzajaCvorovaKojiSuListovi(cvor.left);
    }

    int size = 0;
    public TreeNode<E> root;
    Comparator<? super E> comparator = null;

    /**
     * Create an empty binary tree
     */
    public BinarnoStablo() {
    }

    /**
     * Create a binary tree from an array
     */
    public BinarnoStablo(E[] niz) {
        for (int i = 0; i < niz.length; i++) {
            insert(niz[i]);
        }
    }

    /**
     * Create a binary tree from a collection
     */
    public BinarnoStablo(Collection<E> collection) {
        Iterator<E> iterator = collection.iterator();
        while (iterator.hasNext()) {
            insert(iterator.next());
        }
    }

    public BinarnoStablo(Comparator<? super E> comparator) {
        this.comparator = comparator;
    }

    protected TreeNode<E> createNewNode(E e, TreeNode<E> parent) {
        TreeNode<E> node = new TreeNode<>(e);
        node.parent = parent;
        return node;
    }

    /**
     * Insert element e into the binary tree <br>
     * Return true if the element is inserted successfully
     */
    @Override
    public boolean insert(E e) {
        if (root == null) {
            root = createNewNode(e, null);
        } else {
            TreeNode<E> parent = null;
            TreeNode<E> curr = root;
            while (curr != null) {
                if (comparator != null) {
                    if (comparator.compare(e, curr.element) < 0) {
                        parent = curr;
                        curr = curr.left;
                    } else if (comparator.compare(e, curr.element) > 0) {
                        parent = curr;
                        curr = curr.right;
                    } else {
                        return false;
                    }
                } else {
                    if (e.compareTo(curr.element) < 0) {
                        parent = curr;
                        curr = curr.left;
                    } else if (e.compareTo(curr.element) > 0) {
                        parent = curr;
                        curr = curr.right;
                    } else {
                        return false;
                    }
                }
            }

            if (comparator != null) {
                if (comparator.compare(e, parent.element) < 0) {
                    parent.left = createNewNode(e, parent);
                } else {
                    parent.right = createNewNode(e, parent);
                }
            } else {
                if (e.compareTo(parent.element) < 0) {
                    parent.left = createNewNode(e, parent);
                } else {
                    parent.right = createNewNode(e, parent);
                }
            }
        }

        size++;
        return true;
    }

    /**
     * Return true if the element is in the tree
     */
    @Override
    public boolean search(E e) {
        TreeNode<E> curr = root;
        while (curr != null) {
            if (comparator != null) {
                if (comparator.compare(e, curr.element) < 0) {
                    curr = curr.left;
                } else if (comparator.compare(e, curr.element) > 0) {
                    curr = curr.right;
                } else {
                    return true;
                }
            } else {
                if (e.compareTo(curr.element) < 0) {
                    curr = curr.left;
                } else if (e.compareTo(curr.element) > 0) {
                    curr = curr.right;
                } else {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Delete an element from the binary tree <br>
     * Return true if the element is deleted successfully <br>
     * Return false if the element is not in the tree
     */
    @Override
    public boolean delete(E e) {
        TreeNode<E> parent = null;
        TreeNode<E> curr = root;
        while (curr != null) {
            if (comparator != null) {
                if (comparator.compare(e, curr.element) < 0) {
                    parent = curr;
                    curr = curr.left;
                } else if (comparator.compare(e, curr.element) > 0) {
                    parent = curr;
                    curr = curr.right;
                } else {
                    break;
                }
            } else {
                if (e.compareTo(curr.element) < 0) {
                    parent = curr;
                    curr = curr.left;
                } else if (e.compareTo(curr.element) > 0) {
                    parent = curr;
                    curr = curr.right;
                } else {
                    break;
                }
            }
        }

        if (curr == null) {
            return false;
        }

        if (curr.left == null) {
            if (parent == null) {
                root = curr.right;
                root.parent = null;
            } else {
                if (comparator != null) {
                    if (comparator.compare(e, parent.element) < 0) {
                        parent.left = curr.right;
                    } else {
                        parent.right = curr.right;
                    }
                } else {
                    if (e.compareTo(parent.element) < 0) {
                        parent.left = curr.right;
                    } else {
                        parent.right = curr.right;
                    }
                }
            }
        } else {
            TreeNode<E> parentOfRightmost = curr;
            TreeNode<E> rightmost = curr.left;

            while (rightmost.right != null) {
                parentOfRightmost = rightmost;
                rightmost = rightmost.right;
            }

            curr.element = rightmost.element;

            if (parentOfRightmost.right == rightmost) {
                parentOfRightmost.right = rightmost.left;
            } else {
                parentOfRightmost.left = rightmost.left;
            }
        }

        size--;
        return true;
    }

    /**
     * Returns a path from the root leading to the specified element
     */
    public ArrayList<TreeNode<E>> path(E e) {
        ArrayList<TreeNode<E>> list = new ArrayList<>();
        TreeNode<E> curr = root;

        while (curr != null) {
            list.add(curr);
            if (comparator != null) {
                if (comparator.compare(e, curr.element) < 0) {
                    curr = curr.left;
                } else if (comparator.compare(e, curr.element) > 0) {
                    curr = curr.right;
                } else {
                    break;
                }
            } else {
                if (e.compareTo(curr.element) < 0) {
                    curr = curr.left;
                } else if (e.compareTo(curr.element) > 0) {
                    curr = curr.right;
                } else {
                    break;
                }
            }
        }

        return list;
    }

    private void inorder(TreeNode<E> root) {
        if (root == null) {
            return;
        }
        inorder(root.left);
        System.out.print(root.element + " ");
        inorder(root.right);
    }

    @Override
    public void inorder() {
        inorder(root);
        System.out.println();
    }

    private void postorder(TreeNode<E> root) {
        if (root == null) {
            return;
        }
        postorder(root.left);
        postorder(root.right);
        System.out.print(root.element + " ");
    }

    @Override
    public void postorder() {
        postorder(root);
        System.out.println();
    }

    private void preorder(TreeNode<E> root) {
        if (root == null) {
            return;
        }
        System.out.print(root.element + " ");
        preorder(root.left);
        preorder(root.right);
    }

    @Override
    public void preorder() {
        preorder(root);
        System.out.println();
    }

    private TreeNode<E> getNode(E element) {
        TreeNode<E> current = root;

        while (current != null) {
            if (element.compareTo(current.element) < 0) {
                current = current.left;
            } else if (element.compareTo(current.element) > 0) {
                current = current.right;
            } else {
                break;
            }
        }

        if (current == null) {
            return null;
        }
        return current;
    }

    public boolean isLeaf(E element) {
        TreeNode<E> node = getNode(element);
        if (node == null) {
            return false;
        }
        return node.left == null && node.right == null;
    }

    public ArrayList<E> getPath(E e) {
        ArrayList<E> list = new ArrayList<>();
        TreeNode<E> node = getNode(e);
        while (node != null) {
            list.add(node.element);
            node = node.parent;
        }
        return list;
    }

    public <E extends Number> int zbir() {
        return zbir((TreeNode<E>) root);
    }

    private <E extends Number> int zbir(TreeNode<E> node) {
        if (node == null) {
            return 0;
        }
        return zbir(node.left) + node.element.intValue() + zbir(node.right);
    }

    public int brojElemenata() {
        return brojElemenata(root);
    }

    private int brojElemenata(TreeNode<E> node) {
        if (node == null) {
            return 0;
        }
        return brojElemenata(node.left) + 1 + brojElemenata(node.right);
    }

    /**
     * Get number of leaves
     */
    public int brojListova() {
        return brojListova(root);
    }

    private int brojListova(TreeNode<E> node) {
        if (node == null) {
            return 0;
        }
        if (node.left == null && node.right == null) {
            return 1;
        }
        return brojListova(node.left) + brojListova(node.right);
    }

    public boolean contains(E e) {
        return contains(root, e);
    }

    private boolean contains(TreeNode<E> node, E e) {
        if (node == null) {
            return false;
        }
        if (e.equals(node.element)) {
            return true;
        }
        if (e.compareTo(node.element) < 0) {
            return contains(node.left, e);
        } else if (e.compareTo(node.element) > 0) {
            return contains(node.right, e);
        } else {
            return false;
        }
    }

    /**
     * Visina, dubina, height, depth, broj nivoa
     */
    public int visina() {
        if (size == 1) {
            return 0;
        }
        return visina(root);
    }

    private int visina(TreeNode<E> node) {
        if (node == null) {
            return -1; // 0
        }
        return 1 + Math.max(visina(node.left), visina(node.right));
    }

    /**
     * Koliko elemenata ima na nivou k
     */
    public int brojElemenataNaNivou(int k) {
        return brojElemenataNaNivou(root, k, 1);
    }

    private int brojElemenataNaNivou(TreeNode<E> node, int k, int nivo) {
        if (node == null) {
            return 0;
        }
        if (nivo == k) {
            return 1;
        } else if (nivo < k) {
            return brojElemenataNaNivou(node.left, k, nivo + 1) + brojElemenataNaNivou(node.right, k, nivo + 1);
        } else {
            return 0;
        }
    }

    /**
     * Pretraga po sirini (BFS)
     */
    public void breadthFirstTraversal() {
        if (root == null) {
            return;
        }
        Queue<TreeNode> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            TreeNode<E> node = queue.poll();
            System.out.print(node.element + " ");
            if (node.left != null) {
                queue.offer(node.left);
            }
            if (node.right != null) {
                queue.offer(node.right);
            }
        }
        System.out.println();
    }

    /**
     * Full bst - svako ima dvoje dece <br><br>
     *
     * A full binary tree (sometimes proper binary tree or 2-tree) is a tree in
     * which every node other than the leaves has two children <br><br>
     *
     * (Test perfect binary tree) A perfect binary tree is a complete binary
     * tree with all levels fully filled; Add a method in the BST class to
     * return true if the tree is a perfect binary tree; (Hint: The number of
     * nodes in a nonempty perfect binary tree is 2^height - 1)
     */
    public boolean isFullBST() {
        return (Math.pow(2, visina() + 1) - 1) == size;
    }

    /**
     * A complete binary tree is a binary tree in which every level, except
     * possibly the last, is completely filled, and all nodes are as far left as
     * possible;
     */
    public boolean isComplete() {
        return isComplete(root, 0, brojElemenata());
    }

    private boolean isComplete(TreeNode<E> root, int index, int numberNodes) {
        // Check if the tree is empty
        if (root == null) {
            return true;
        }
        if (index >= numberNodes) {
            return false;
        }
        return (isComplete(root.left, 2 * index + 1, numberNodes)
                && isComplete(root.right, 2 * index + 2, numberNodes));
    }

    /**
     * Inorder metod bez rekurzije
     */
    public void inorderStack() {
        if (root == null) {
            return;
        }
        Stack<TreeNode> stack = new Stack<>();
        TreeNode<E> current = root;
        while (true) {
            if (current != null) {
                stack.push(current);
                current = current.left;
            } else {
                if (stack.isEmpty()) {
                    break;
                }
                current = stack.pop();
                System.out.print(current.element + " ");
                current = current.right;
            }
        }
    }

    /**
     * Preorder metod bez rekurzije
     */
    public void preorderStack() {
        Stack<TreeNode> stack = new Stack<>();
        stack.add(root);
        while (!stack.isEmpty()) {
            TreeNode<E> node = stack.pop();
            System.out.print(node.element + " ");
            if (node.right != null) {
                stack.push(node.right);
            }
            if (node.left != null) {
                stack.push(node.left);
            }
        }
    }

    /**
     * Postorder metod bez rekurzije
     */
    public void postorderStack() {
        if (root == null) {
            return;
        }
        Stack<TreeNode> stack = new Stack<>();
        stack.push(root);
        TreeNode<E> previous = null;
        while (!stack.isEmpty()) {
            TreeNode<E> current = stack.peek();
            if (previous == null || previous.left == current
                    || previous.right == current) {
                if (current.left != null) {
                    stack.push(current.left);
                } else if (current.right != null) {
                    stack.push(current.right);
                }
            } else if (current.left == previous) {
                if (current.right != null) {
                    stack.push(current.right);
                }
            } else {
                System.out.print(current.element + " ");
                stack.pop();
            }
            previous = current;
        }
    }

    /**
     * Get number of non leaves <br>
     *
     * Broj elemenata koji nisu listovi
     */
    public int brojNeListova() {
        return brojElemenata() - brojListova();
    }

    @Override
    public int getSize() {
        return size;
    }

    @Override
    public Iterator<E> iterator() {
        return new InorderIterator();
    }

    //<editor-fold defaultstate="collapsed" desc="ostalo">
    // Inner class InorderIterator
    private class InorderIterator implements Iterator<E> {

        // Store the elements in a list
        private ArrayList<E> list = new ArrayList<>();
        private int current = 0; // Point to the current element in list

        public InorderIterator() {
            inorder(); // Traverse binary tree and store elements in list
        }

        /**
         * Inorder traversal from the root
         */
        private void inorder() {
            inorder(root);
        }

        /**
         * Inorder traversal from a subtree
         */
        private void inorder(TreeNode<E> root) {
            if (root == null) {
                return;
            }
            inorder(root.left);
            list.add(root.element);
            inorder(root.right);
        }

        @Override
        /**
         * More elements for traversing?
         */
        public boolean hasNext() {
            if (current < list.size()) {
                return true;
            }

            return false;
        }

        @Override
        /**
         * Get the current element and move to the next
         */
        public E next() {
            return list.get(current++);
        }

        @Override
        /**
         * Remove the current element
         */
        public void remove() {
            if (current == 0) // next() has not been called yet
            {
                throw new IllegalStateException();
            }

            delete(list.get(--current));
            list.clear(); // Clear the list
            inorder(); // Rebuild the list
        }
    }

    public ListIterator<E> listIterator() {
        return new BidirectionalIterator();
    }

    private class BidirectionalIterator implements ListIterator<E> {

        private ArrayList<E> list = new ArrayList<>();
        private int current = 0;

        public BidirectionalIterator() {
            inorder();
        }

        private void inorder() {
            inorder(root);
        }

        private void inorder(TreeNode<E> node) {
            if (node == null) {
                return;
            }
            inorder(node.left);
            list.add(node.element);
            inorder(node.right);
        }

        @Override
        public boolean hasNext() {
            if (current < list.size()) {
                return true;
            }
            return false;
        }

        @Override
        public boolean hasPrevious() {
            if (current >= 0) {
                return true;
            }
            return false;
        }

        @Override
        public E next() {
            return list.get(current++);
        }

        @Override
        public E previous() {
            return list.get(current--);
        }

        @Override
        public int nextIndex() {
            return current;
        }

        @Override
        public int previousIndex() {
            return current;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("remove() not supported");
        }

        @Override
        public void add(E e) {
            throw new UnsupportedOperationException("add(E e) not supported");
        }

        @Override
        public void set(E e) {
            throw new UnsupportedOperationException("set(E e) not supported");
        }
    }

    private class BreadthFirstIterator implements Iterator<E> {

        private ArrayList<E> list = new ArrayList<>();
        private int current = 0;

        public BreadthFirstIterator() {
            breadthFirst();
        }

        private void breadthFirst() {
            if (root == null) {
                return;
            }
            Queue<TreeNode<E>> queue = new LinkedList<>();
            queue.offer(root);
            while (!queue.isEmpty()) {
                TreeNode<E> node = queue.poll();
                list.add(node.element);
                if (node.left != null) {
                    queue.offer(node.left);
                }
                if (node.right != null) {
                    queue.offer(node.right);
                }
            }
        }

        @Override
        public boolean hasNext() {
            if (current < list.size()) {
                return true;
            }
            return false;
        }

        @Override
        public E next() {
            return list.get(current++);
        }
    }

    @Override
    public void clear() {
        root = null;
        size = 0;
    }

    @Override
    protected Object clone() {
        BinarnoStablo<E> copy = new BinarnoStablo<>();
        Iterator<E> iter = new BreadthFirstIterator();
        while (iter.hasNext()) {
            copy.insert(iter.next());
        }
        return copy;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof BinarnoStablo)) {
            return false;
        }
        BinarnoStablo<E> c = (BinarnoStablo<E>) obj;
        ArrayList<E> list1 = inorderList();
        ArrayList<E> list2 = c.inorderList();
        return list1.equals(list2);
    }

    public ArrayList<E> inorderList() {
        ArrayList<E> list = new ArrayList<>();
        inorderList(list, root);
        return list;
    }

    private void inorderList(ArrayList<E> list, TreeNode<E> node) {
        if (node == null) {
            return;
        }
        inorderList(list, node.left);
        list.add(node.element);
        inorderList(list, node.right);
    }

    public Iterator<E> preorderIterator() {
        return new PreorderIterator();
    }

    private class PreorderIterator implements Iterator<E> {

        private ArrayList<E> list = new ArrayList<>();
        private int current = 0;

        public PreorderIterator() {
            preorder();
        }

        private void preorder() {
            preorder(root);
        }

        private void preorder(TreeNode<E> node) {
            if (node == null) {
                return;
            }
            list.add(node.element);
            preorder(node.left);
            preorder(node.right);
        }

        @Override
        public boolean hasNext() {
            if (current < list.size()) {
                return true;
            }
            return false;
        }

        @Override
        public E next() {
            return list.get(current++);
        }
    }
    //</editor-fold>
}
