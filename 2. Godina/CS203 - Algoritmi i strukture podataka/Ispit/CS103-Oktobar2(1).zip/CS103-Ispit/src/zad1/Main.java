/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zad1;

/**
 *
 * @author student
 */
public class Main {
    
    public static void main(String[] args) {
        BinarnoStablo<Integer> bst = new BinarnoStablo<>(new Integer[]{55,12,5,0,-3,56,90,23});        
        System.out.println(bst.metod());
    }
}
