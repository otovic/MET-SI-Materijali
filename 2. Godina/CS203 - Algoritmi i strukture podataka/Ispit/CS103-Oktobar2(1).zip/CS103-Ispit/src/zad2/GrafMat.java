/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zad2;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

/**
 *
 * @author student
 */
public class GrafMat {

    int vCount;
    int eCount;

    boolean[][] adj;

    public GrafMat(int vCount) {
        this.vCount = vCount;
        adj = new boolean[vCount][vCount];
    }

    public void addEdge(int u, int v) {
        adj[u][v] = true;
        //adj[v][u] = true; // ako hocemo neusmeren graf
        eCount++; // broj
    }

    public void removeEdge(int u, int v) {
        adj[u][v] = false;
        //adj[v][u] = false; // ako hocemo neusmeren graf
        eCount--; // broj
    }

    public boolean hasEdge(int u, int v) {
        return adj[u][v];
    }

    /**
     * Vremenska slozenost: O(vCount)
     */
    public int outDegree(int vertex) {
        int count = 0;
        for (int i = 0; i < vCount; i++) {
            if (adj[vertex][i]) { // == true
                count++;
            }
        }
        return count;
//       adj[vertex][0];
//       adj[vertex][1];
//       adj[vertex][2];
//       adj[vertex][3];
    }

    /**
     * Vremenska slozenost: O(vCount)
     */
    public int inDegree(int vertex) {
        int count = 0;
        for (int i = 0; i < vCount; i++) {
            if (adj[i][vertex]) {
                count++;
            }
        }
        return count;
//        adj[0][vertex];
//        adj[1][vertex];
//        adj[2][vertex];
//        adj[3][vertex];
    }

    public List<Integer> neighbours(int vertex) {
        List<Integer> edges = new ArrayList<Integer>();
        for (int i = 0; i < vCount; i++) {
            if (adj[vertex][i]) {
                edges.add(i);
            }
        }
        return edges;
    }

    public void printGraph() {
        for (int i = 0; i < vCount; i++) {
            List<Integer> edges = neighbours(i);
            System.out.print(i + ": ");
            for (int j = 0; j < edges.size(); j++) {
                System.out.print(edges.get(j) + " ");
            }
            System.out.println();
        }
    }

    public void outDegreeAll() {
        for (int i = 0; i < vCount; i++) {
            int outDegree = this.outDegree(i);
            System.out.println("Čvor {" + i + "} =>" + " broj izlaznih (outDegree): " + outDegree);
        }
    }
    
    public void inDegreeAll() {
        for (int i = 0; i < vCount; i++) {
            int inDegree = this.inDegree(i);
            System.out.println("Čvor {" + i + "} =>" + " broj ulaznih (inDegree): " + inDegree);
        }
    }

    void BFS(int start) {
        boolean[] visited = new boolean[vCount];
        Arrays.fill(visited, false);
        LinkedList<Integer> q = new LinkedList<>();
        q.add(start);

        visited[start] = true;

        int vis;
        while (!q.isEmpty()) {
            vis = q.get(0);

            System.out.print(vis + " ");
            q.remove(q.get(0));

            for (int i = 0; i < vCount; i++) {
                if (adj[vis][i] == true && (!visited[i])) {
                    q.add(i);
                    visited[i] = true;
                }
            }
        }
        System.out.println();
    }

    void BFS_rek(int start) {
        LinkedList<Integer> q = new LinkedList<>();
        q.offer(start);
        boolean[] visited = new boolean[vCount];
        visited[start] = true;
        Arrays.fill(visited, false);
        BFS_rek(q, visited);
    }

    void BFS_rek(LinkedList<Integer> q, boolean[] visited) {
        if (q.isEmpty()) {
            return;
        }

        int v = q.poll();
        System.out.println(v);
        visited[v] = true;
        for (int i = 0; i < vCount; i++) {
            if (!visited[i] && adj[v][i] == true) {
                visited[i] = true;
                q.offer(i);
            }
        }
        BFS_rek(q, visited);
    }

    void DFS(int v) {
        boolean[] visited = new boolean[vCount];
        Stack<Integer> s = new Stack<>();
        Arrays.fill(visited, false);
        s.push(v);

        while (!s.isEmpty()) {
            int newV;
            newV = s.pop();

            if (!visited[newV]) {
                visited[newV] = true;
                System.out.println(newV);
                for (int i = vCount - 1; i >= 0; i--) {
                    if (adj[newV][i] == true && !visited[i]) {
                        s.push(i);
                    }
                }
            }
        }
    }

    void DFS_rek(int vStart) {
        boolean[] visited = new boolean[vCount];
        DFS_rek(vStart, visited);
    }

    private void DFS_rek(int vStart, boolean[] visited) {
        System.out.println(vStart);
        visited[vStart] = true;

        for (int i = 0; i < vCount; i++) {
            if (adj[vStart][i] == true && (!visited[i])) {
                DFS_rek(i, visited);
            }
        }
    }

    int count_dfs_prikaz = 0;

    boolean dfs_prikaz(int vStart, int vEnd) {
        boolean[] visited = new boolean[vCount];
        if (!dfs_prikaz(vStart, vEnd, visited, count_dfs_prikaz)) {
            System.out.println("count=" + count_dfs_prikaz);
            System.out.println("Cvor b nije dostizan.");
            return false;
        } else {
            System.out.println("count=" + count_dfs_prikaz);
            System.out.println("Cvor b je dostizan.");
            return true;
        }
    }

    private boolean dfs_prikaz(int vStart, int vEnd, boolean[] visited, int count) {
        System.out.println(vStart);
        visited[vStart] = true;
        this.count_dfs_prikaz++;
        if (isThereADirectPath(vStart, vEnd)) {
            return true;
        } else {
            for (int i = 0; i < vCount; i++) {
                if (adj[vStart][i] == true && (!visited[i])) {
                    if (dfs_prikaz(i, vEnd, visited, this.count_dfs_prikaz)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    boolean bfs_prikaz(int start, int end) {
        if (!bfs_prikaz_util(start, end)) {
            System.out.println("Cvor b nije dostizan.");
            return false;
        } else {
            System.out.println("Cvor b je dostizan.");
            return true;
        }
    }

    private boolean bfs_prikaz_util(int start, int end) {
        boolean[] visited = new boolean[vCount];
        Arrays.fill(visited, false);
        LinkedList<Integer> q = new LinkedList<>();
        q.add(start);

        visited[start] = true;
        int count = 0;
        int vis;
        while (!q.isEmpty()) {
            vis = q.get(0);
            count++;
            System.out.print(vis + " ");
            if (vis == end) {
                System.out.println("\ncount=" + count);
                return true;
            } else {
                q.remove(q.get(0));

                for (int i = 0; i < vCount; i++) {
                    if (adj[vis][i] == true && (!visited[i])) {
                        q.add(i);
                        visited[i] = true;
                    }
                }
            }
        }
        System.out.println();
        System.out.println("count=" + count);
        return false;
    }

    /**
     * Za usmeren graf zadat matricom povezanosti izračunati prosečan, minimalni
     * i maksimalni ulazni i izlazni stepen čvorova.
     */
    void m() {
        int minInDegree = inDegree(0);
        int minInK = 0;

        int maxInDegree = inDegree(0);
        int maxInK = 0;

        int minOutDegree = outDegree(0);
        int minOutK = 0;

        int maxOutDegree = outDegree(0);
        int maxOutK = 0;

        int sumaOut = 0;
        int sumaIn = 0;

        for (int i = 0; i < vCount; i++) {
            if (inDegree(i) < minInDegree) { // ako postoji manji
                minInDegree = inDegree(i); // onda je taj manji
                minInK = i;
            }
            if (inDegree(i) > maxInDegree) { // ako postoji veci
                maxInDegree = inDegree(i); // onda je taj veci
                maxInK = i;
            }
            if (outDegree(i) < minOutDegree) { // ako postoji manji
                minOutDegree = outDegree(i); // onda je taj manji
                minOutK = i;
            }
            if (outDegree(i) > maxOutDegree) { // ako postoji manji
                maxOutDegree = outDegree(i); // onda je taj manji
                maxOutK = i;
            }

            sumaIn += inDegree(i);
            sumaOut += outDegree(i);
        }

        System.out.println("maxOut = cvor{" + (maxOutK) + "} = " + maxOutDegree);
        System.out.println("minOut = cvor{" + (minOutK) + "} = " + minOutDegree);

        System.out.println("maxIn = cvor{" + (maxInK) + "} = " + maxInDegree);
        System.out.println("minIn = cvor{" + (minInK) + "} = " + minInDegree);

        System.out.println("avgIn = " + (sumaIn / vCount));
        System.out.println("avgOut = " + (sumaOut / vCount));
    }

    public static void main(String[] args) {
        GrafMat g = new GrafMat(4);
        g.addEdge(0, 1);
        g.addEdge(0, 2);
        g.addEdge(2, 3);
        g.addEdge(3, 1);

        /**
         * Za graf zadat matricom povezanosti pokrenuti BFS i DFS pretragu iz
         * čvora A. Zaustaviti pretragu kada se dostigne čvor B. Ispisati koliko
         * čvorova je posetio BFS, a koliko DFS. U slučaju da čvor B nije
         * dostižan iz čvora A, ispisati odgovarajuću poruku.
         */
        System.out.println("DFS:");
        System.out.println(g.dfs_prikaz(2, 0));
        System.out.println("----");
        System.out.println("BFS:");
        System.out.println(g.bfs_prikaz(2, 0));

        /**
         * Za usmeren graf zadat matricom povezanosti izračunati prosečan,
         * minimalni i maksimalni ulazni i izlazni stepen čvorova.
         */
        System.out.println("---");
        g.m();
    }

    int[][] matUdaljenosti; // beleziti u matrici

    /**
     * Kreirati metod koji za svaki čvor od grafa računa njegovu udaljenost od
     * ostalih čvorova. Smatrati da je čvor od samog sebe udaljen 0 čvorova, od
     * prvog suseda 1 i tako redom. Udaljenosti beležiti u matrici udaljenosti.
     * Napisati program koji testira metod.
     */
    public int distance(int vertex) {
        boolean visited[] = new boolean[vCount];
        Queue<Integer> queue = new ArrayDeque<>();

        visited[vertex] = true;
        queue.add(vertex);

        int distance = 0;

        while (!queue.isEmpty()) {
            int v = queue.poll();
            distance++;
            for (int i = 0; i < vCount; i++) {
                if (!visited[i] && adj[v][i]) {
                    //System.out.println("Distance from vertex: " + vertex + " to " + i + " = " + distance);
                    matUdaljenosti[vertex][i] = distance; // beleziti u matrici
                    visited[i] = true;
                    queue.add(i);
                }
            }
        }

        return distance == 0 ? -1 : distance;
    }

    /**
     * Da li se moze doci od cvora vStart do cvora zadati
     */
    boolean isThereADirectPath(int vStart, int zadati) {
        if (adj[vStart][zadati]) {
            return true;
        }
        return false;
    }

    /**
     * Kreirati funkciju koji za proizvoljno k nalazi sve puteve dužine k u
     * usmerenom grafu koji je dat matricom povezanosti. Napisati program koji
     * testira funkciju.
     */
    void puteviDuzineK(int k) {
        System.out.println("Putevi duzine " + (k) + ":");
        for (int i = 0; i < matUdaljenosti.length; i++) {
            for (int j = 0; j < matUdaljenosti[i].length; j++) {
                if (matUdaljenosti[i][j] == k) {
                    System.out.println("od " + i + " do " + j + " = " + (k));
                }
            }
        }
    }

    /**
     * Napisati program koji predstavlja graf preko matrice povezanosti i
     * dozvoljava korisniku da odabere dva čvora. Program zatim treba da proveri
     * da li postoji direktan ili indirektan put od prvog do drugog unetog čvora
     * i o tome da obavesti korisnika.
     */
    boolean path(int start, int end) {
        boolean[] visited = new boolean[vCount];
        List<Integer> lista = new ArrayList<>();
        if (path(start, end, visited, lista)) {
            if (visited[start]) {
                System.out.println("Indirektan put");
            } else {
                System.out.println("Direktan put");
            }
            System.out.println(lista);
            return true;
        }
        return false;
    }

    private boolean path(int start, int end, boolean[] visited, List<Integer> lista) {
        //System.out.println(start);
        lista.add(start);
        if (isThereADirectPath(start, end)) {
            lista.add(end);
            //System.out.println(end);
            return true;
        } else {
            visited[start] = true;
            for (int i = 0; i < vCount; i++) {
                if (adj[start][i] == true && (!visited[i])) {
                    return path(i, end, visited, lista); //ako ne radi, probaj sa onakvim if kao mrkela
                }
            }
        }
        return false;
    }

    /**
     * Napisati funkciju koja proverava da li je graf cikličan. Napisati program
     * koji testira ovu funkciju. Graf je ciklican ako ima barem jedan kruzni
     * put
     */
    boolean isCyclic() {
        boolean[] visited = new boolean[vCount];
        boolean[] recStack = new boolean[vCount];

        for (int i = 0; i < vCount; i++) {
            if (isCyclicUtil(i, visited, recStack)) {
                return true;
            }
        }

        return false;
    }

    private boolean isCyclicUtil(int i, boolean[] visited, boolean[] recStack) {
        if (recStack[i]) {
            return true;
        }

        if (visited[i]) {
            return false;
        }

        visited[i] = true;

        recStack[i] = true;
        for (int j = 0; j < vCount; j++) {
            if (isCyclicUtil(j, visited, recStack) && adj[i][j]) {
                return true;
            }
        }
        recStack[i] = false;
        return false;
    }

    /**
     * Graf je neusmeren ako svaka grana ima A->B i B->A granu <br>
     * Na osnovu matrice povezanosti proveriti da li je graf neusmeren. Graf je
     * neusmeren ako ima i AB i BA granu. Ovo treba da važi za svaku granu.
     */
    boolean isUndirected() {
        for (int i = 0; i < adj.length; i++) {
            for (int j = 0; j < adj[i].length; j++) {
                if (adj[i][j] != adj[j][i]) {
                    return false;
                }
            }
        }
        return true;
    }
}

class TestGrafMat {

    public static void main(String[] args) {
        GrafMat g = new GrafMat(4);
//        g.addEdge(0, 1);
//        g.addEdge(0, 3);
//
//        g.addEdge(1, 2);
//        g.addEdge(1, 3);
//
//        g.addEdge(2, 0);
//
//        g.addEdge(3, 2);

        g.addEdge(0, 1);
        g.addEdge(1, 2);
        g.addEdge(2, 3);
        g.addEdge(2, 1);

        System.out.println(g.outDegree(3));
        System.out.println(g.inDegree(3));

        System.out.println("---");
        g.printGraph();

        System.out.println("------BFS");
        g.BFS(0);

        System.out.println("-------BFS_rek");
        g.BFS_rek(0);

        System.out.println("----DFS");
        g.DFS(0);

        System.out.println("------DFS_rek");
        g.DFS_rek(0);

        System.out.println("-----distance");
        g.matUdaljenosti = new int[g.vCount][g.vCount];
        for (int i = 0; i < 4; i++) {
            g.distance(i);
        }
        printMat(g.matUdaljenosti);

        System.out.println("-------");
        g.puteviDuzineK(2);

        System.out.println("------");
        System.out.println(g.isThereADirectPath(0, 3));

        System.out.println("-------");
        System.out.println(g.path(0, 3));

        System.out.println("------ciklicnost");
        System.out.println(g.isCyclic());

        System.out.println("--------da li je graf neusmeren");
        System.out.println(g.isUndirected());
    }

    static void printMat(int[][] mat) {
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print(mat[i][j] + " ");
            }
            System.out.println();
        }
    }
}
