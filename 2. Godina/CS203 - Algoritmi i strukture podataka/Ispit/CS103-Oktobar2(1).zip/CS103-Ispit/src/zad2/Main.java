/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zad2;

/**
 *
 * @author student
 */
public class Main {
    public static void main(String[] args) {
        GrafMat g = new GrafMat(4);
        
        g.addEdge(0, 1);
        g.addEdge(1, 2);
        g.addEdge(2, 3);
        g.addEdge(2, 1);
        
        System.out.println("OutDegree (izlazni):");
        g.outDegreeAll();
        System.out.println("----");
        System.out.println("");
        System.out.println("InDegree (ulazni):");
        g.inDegreeAll();
        System.out.println("----");
    }
}
