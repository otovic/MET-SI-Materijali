/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zad4;

/**
 *
 * @author student
 */
public class Main {

    private static String minWord = "";

    private static void najmanjeDuzineRec(String tekst) {
        tekst = tekst.trim();
        int len = tekst.length();
        int si = 0, ei = 0;
        int min_length = len, min_start_index = 0,
                max_length = 0;

        while (ei <= len) {
            if (ei < len && tekst.charAt(ei) != ' ') {
                ei++;
            } else {
                int curr_length = ei - si;

                if (curr_length < min_length) {
                    min_length = curr_length;
                    min_start_index = si;
                }

                if (curr_length > max_length) {
                    max_length = curr_length;
                }
                ei++;
                si = ei;
            }
        }

        minWord = tekst.substring(min_start_index, min_start_index + min_length);
    }

    private static void recKojaSePonavljaKPuta(String tekst, String rec, int k) {
        String[] split = tekst.split(" ");
        int counter = 0;
        for (int i = 0; i < split.length; i++) {
            //System.out.print(split[i]);
            for (int j = i + 1; j < split.length; j++) {
                //System.out.println(" => " + split[j]);          
                if (split[i].equals(split[j])) {
                    counter++;
                }
            }
        }
        if (counter == k) {
            System.out.println("Najmanja reč koja se ponavlja " + k + " puta je: \n" + rec);
        } else {
            System.out.println("Nema najmanje reči koja se ponavlja " + k + " puta.");
        }
    }

    public static void main(String[] args) {
        String tekst = "GeeksforGeeks As Computer Science portal for Geeks As";
        
        najmanjeDuzineRec(tekst);
        
        int k = 4;

        recKojaSePonavljaKPuta(tekst, minWord, k);
    }
}
