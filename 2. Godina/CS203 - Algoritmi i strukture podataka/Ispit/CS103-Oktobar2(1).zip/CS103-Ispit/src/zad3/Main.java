/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zad3;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author student
 */
public class Main {

    public static void main(String[] args) throws IOException {
        permutacije("abc");        
    }

    public static void permutacije(String str) throws IOException {
        List<String> list = new ArrayList<>();
        permutacije(str, "", list);
        write("permutacijeSlova.txt", list.toString().substring(1, list.toString().length()-1));
    }

    /**
     * Prikazi sve permutacije (kombinacije karaktera) datog stringa.
     * Rekurzija.permutacije("abc", ""); output: abc, bac, cba...
     */
    private static void permutacije(String str, String ans, List<String> list) {
        if (str.length() == 0) {
            System.out.print(ans + " ");
            list.add(ans + " ");
            return;
        }
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            String ros = str.substring(0, i) + str.substring(i + 1);
            permutacije(ros, ans + ch, list);
        }
    }

    public static void write(String fileName, String toWrite)
            throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
        writer.write(toWrite);

        writer.close();
    }
}
