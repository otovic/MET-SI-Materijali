/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Z5;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Jovan Sekulovic 4211
 */
public class Program {
    public static void main(String[] args) throws IOException {
        Program z = new Program();
        System.out.println("ulaz.txt:\n");
        for (String string : z.ucitaj("ulaz.txt")) {
            System.out.println(string);
        }
        System.out.println("----");
        System.out.println("\nizlaz.txt:\n");
        List<String> list = z.sortirajIVrati("ulaz.txt");
        write("izlaz.txt", list.toString().substring(1, list.toString().length()-1));
        for (String string : z.ucitaj("izlaz.txt")) {
            System.out.println(string);
        }        
    }    
    
    public static void write(String fileName, String toWrite)
            throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
        writer.write(toWrite);

        writer.close();
    }
    
    ArrayList<String> ucitaj(String fileName) {
        ArrayList<String> list = new ArrayList<>();
        Scanner sc = null;
        try {
            sc = new Scanner(new File(fileName));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Program.class.getName()).log(Level.SEVERE, null, ex);
        }
        while (sc.hasNext()) {            
            String next = sc.nextLine();
           // System.out.println(next);
            list.add(next);
        }
        return list;
    }
    
    ArrayList<String> sortirajIVrati(String fileName) {
        ArrayList<String> list = ucitaj(fileName);
        SelectionSort.selectionSort(list);
        return list;
    }
}
