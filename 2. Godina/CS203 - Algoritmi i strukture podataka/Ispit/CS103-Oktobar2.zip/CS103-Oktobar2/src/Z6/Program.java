/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Z6;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Jovan Sekulovic 4211
 */
public class Program {
    
   static String reg = "^(?!.*\\.\\.)(?!.*\\.$)[^\\W][\\w.]{0,29}$";

    public static void main(String[] args) {
        
        System.out.println(run("jovan.sekulovic.4211"));
        System.out.println(run(".a.b.1"));
        System.out.println(run("a.b.1."));
        System.out.println(run("a..b.1"));
    }

    static boolean run(String str) {
        Pattern pattern = Pattern.compile(reg);
        Matcher matcher = pattern.matcher(str);
        return matcher.matches();
    }
}
