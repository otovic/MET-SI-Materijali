/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Z2;

/**
 *
 * @author Jovan Sekulovic 4211
 */
public class Program {

    void stampajUlazne() {
    }

    public static void main(String[] args) {

        MatricaGraf grafMatriceObjekat = null;
//grafMatriceObjekat = new MatricaGraf(8);
        grafMatriceObjekat = new MatricaGraf(3); // 3 cvora 0,1,2

        grafMatriceObjekat.dodajGranu(1, 0);// 1->0
        grafMatriceObjekat.dodajGranu(2, 0);
        grafMatriceObjekat.dodajGranu(1, 2);
        grafMatriceObjekat.dodajGranu(2, 1);

        // stampaj rezultate
        for (int c = 0; c < grafMatriceObjekat.vCount; c++) {
            System.out.print(c + " ");
            //System.out.println(c);
            System.out.println("stepen izlaza = " + grafMatriceObjekat.izlazniStepen(c));
        }

        System.out.println("\n");

        for (int c = 0; c < grafMatriceObjekat.vCount; c++) {
            //System.out.println(c);
            System.out.print(c + " ");
            System.out.println("stepen ulaza = " + grafMatriceObjekat.ulazniStepen(c));
        }

    }

}
