/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Z2;


/**
 *
 * @author Jovan Sekulovic 4211
 */
public class MatricaGraf {

    public int izlazniStepen(int v) {
        int brojac = 0;
        for (int i = 0; i < vCount; i++) {
            if (adj[v][i]) {
                brojac++;
            }
        }
        return brojac;
    }

    public int ulazniStepen(int v) {
        int brojac = 0;
        for (int i = 0; i < vCount; i++) {
            if (adj[i][v]) {
                brojac++;
            }
        }
        return brojac;
    }

    int vCount;
    int eCount;

    private boolean[][] adj;

    public MatricaGraf(int vCount) {
        this.vCount = vCount;
        adj = new boolean[vCount][vCount];
    }

    public void dodajGranu(int u, int v) {
        adj[u][v] = true;
        eCount++;
    }

    public void obrisiGranu(int u, int v) {
        adj[u][v] = false;
        eCount--;
    }

    public boolean daLiImaGranu(int u, int v) {
        return adj[u][v];
    }   

}