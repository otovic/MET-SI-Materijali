package Z1;

/**
 *
 * @author Jovan Sekulovic 4211
 */
public class Program {

    public static void main(String[] args) {
        BSTGeneric<Integer> bst = new BSTGeneric<Integer>();

        // unos
        bst.insert(66);
        bst.insert(11);
        bst.insert(24);
        bst.insert(35);
        bst.insert(99);
        bst.insert(118);
        bst.insert(45);
        bst.insert(34);

        // rezultat
        boolean result = bst.daLiJeDeljivSaKorenom();
        
        System.out.println(result); //
    }
}
