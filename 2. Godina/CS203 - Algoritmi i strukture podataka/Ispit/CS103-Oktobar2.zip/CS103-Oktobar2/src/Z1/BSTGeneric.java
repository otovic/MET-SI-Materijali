/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Z1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Queue;
import java.util.Stack;

/**
 *
 * @author Jovan Sekulovic 4211
 */
public class BSTGeneric<E extends Comparable<E>> implements BSTTree<E>, Cloneable {

    
    

    int size = 0;
    public BST_Node<E> root;
    Comparator<? super E> comparator = null;

    /**
     * Create an empty binary tree
     */
    public BSTGeneric() {
    }

    /**
     * Create a binary tree from an array
     */
    public BSTGeneric(E[] niz) {
        for (int i = 0; i < niz.length; i++) {
            insert(niz[i]);
        }
    }

    /**
     * Create a binary tree from a collection
     */
    public BSTGeneric(Collection<E> collection) {
        Iterator<E> iterator = collection.iterator();
        while (iterator.hasNext()) {
            insert(iterator.next());
        }
    }

    public BSTGeneric(Comparator<? super E> comparator) {
        this.comparator = comparator;
    }

    protected BST_Node<E> createNewNode(E e, BST_Node<E> parent) {
        BST_Node<E> node = new BST_Node<>(e);
        return node;
    }

    /**
     * Insert element e into the binary tree <br>
     * Return true if the element is inserted successfully
     */
    @Override
    public boolean insert(E e) {
        if (root == null) {
            root = createNewNode(e, null);
        } else {
            BST_Node<E> parent = null;
            BST_Node<E> curr = root;
            while (curr != null) {
                if (comparator != null) {
                    if (comparator.compare(e, curr.element) < 0) {
                        parent = curr;
                        curr = curr.left;
                    } else if (comparator.compare(e, curr.element) > 0) {
                        parent = curr;
                        curr = curr.right;
                    } else {
                        return false;
                    }
                } else {
                    if (e.compareTo(curr.element) < 0) {
                        parent = curr;
                        curr = curr.left;
                    } else if (e.compareTo(curr.element) > 0) {
                        parent = curr;
                        curr = curr.right;
                    } else {
                        return false;
                    }
                }
            }

            if (comparator != null) {
                if (comparator.compare(e, parent.element) < 0) {
                    parent.left = createNewNode(e, parent);
                } else {
                    parent.right = createNewNode(e, parent);
                }
            } else {
                if (e.compareTo(parent.element) < 0) {
                    parent.left = createNewNode(e, parent);
                } else {
                    parent.right = createNewNode(e, parent);
                }
            }
        }

        size++;
        return true;
    }
    
    <E extends Number> boolean daLiJeDeljivSaKorenom() {
        
        E e = (E) root.element; // koreni element broj
        int zbir = zbirListova((BST_Node<E>) root);
        
        if (zbir % e.doubleValue() == 0) {
            
            return true;
            
        } else {
            return false;
        }
    }

    /**
     * Return true if the element is in the tree
     */
    @Override
    public boolean search(E e) {
        BST_Node<E> curr = root;
        while (curr != null) {
            if (comparator != null) {
                if (comparator.compare(e, curr.element) < 0) {
                    curr = curr.left;
                } else if (comparator.compare(e, curr.element) > 0) {
                    curr = curr.right;
                } else {
                    return true;
                }
            } else {
                if (e.compareTo(curr.element) < 0) {
                    curr = curr.left;
                } else if (e.compareTo(curr.element) > 0) {
                    curr = curr.right;
                } else {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Delete an element from the binary tree <br>
     * Return true if the element is deleted successfully <br>
     * Return false if the element is not in the tree
     */
    @Override
    public boolean delete(E e) {
        BST_Node<E> parent = null;
        BST_Node<E> curr = root;
        while (curr != null) {
            if (comparator != null) {
                if (comparator.compare(e, curr.element) < 0) {
                    parent = curr;
                    curr = curr.left;
                } else if (comparator.compare(e, curr.element) > 0) {
                    parent = curr;
                    curr = curr.right;
                } else {
                    break;
                }
            } else {
                if (e.compareTo(curr.element) < 0) {
                    parent = curr;
                    curr = curr.left;
                } else if (e.compareTo(curr.element) > 0) {
                    parent = curr;
                    curr = curr.right;
                } else {
                    break;
                }
            }
        }

        if (curr == null) {
            return false;
        }

        if (curr.left == null) {
            if (parent == null) {
                root = curr.right;
            } else {
                if (comparator != null) {
                    if (comparator.compare(e, parent.element) < 0) {
                        parent.left = curr.right;
                    } else {
                        parent.right = curr.right;
                    }
                } else {
                    if (e.compareTo(parent.element) < 0) {
                        parent.left = curr.right;
                    } else {
                        parent.right = curr.right;
                    }
                }
            }
        } else {
            BST_Node<E> parentOfRightmost = curr;
            BST_Node<E> rightmost = curr.left;

            while (rightmost.right != null) {
                parentOfRightmost = rightmost;
                rightmost = rightmost.right;
            }

            curr.element = rightmost.element;

            if (parentOfRightmost.right == rightmost) {
                parentOfRightmost.right = rightmost.left;
            } else {
                parentOfRightmost.left = rightmost.left;
            }
        }

        size--;
        return true;
    }

    /**
     * Returns a path from the root leading to the specified element
     */
    public ArrayList<BST_Node<E>> path(E e) {
        ArrayList<BST_Node<E>> list = new ArrayList<>();
        BST_Node<E> curr = root;

        while (curr != null) {
            list.add(curr);
            if (comparator != null) {
                if (comparator.compare(e, curr.element) < 0) {
                    curr = curr.left;
                } else if (comparator.compare(e, curr.element) > 0) {
                    curr = curr.right;
                } else {
                    break;
                }
            } else {
                if (e.compareTo(curr.element) < 0) {
                    curr = curr.left;
                } else if (e.compareTo(curr.element) > 0) {
                    curr = curr.right;
                } else {
                    break;
                }
            }
        }

        return list;
    }

    private void inorder(BST_Node<E> root) {
        if (root == null) {
            return;
        }
        inorder(root.left);
        System.out.print(root.element + " ");
        inorder(root.right);
    }

    @Override
    public void inorder() {
        inorder(root);
        System.out.println();
    }

    private void postorder(BST_Node<E> root) {
        if (root == null) {
            return;
        }
        postorder(root.left);
        postorder(root.right);
        System.out.print(root.element + " ");
    }

    @Override
    public void postorder() {
        postorder(root);
        System.out.println();
    }

    private void preorder(BST_Node<E> root) {
        if (root == null) {
            return;
        }
        System.out.print(root.element + " ");
        preorder(root.left);
        preorder(root.right);
    }

    @Override
    public void preorder() {
        preorder(root);
        System.out.println();
    }


    
    <E extends Number> int zbirListova(BST_Node<E> root) {
        
        int sum = 0;        
        if (root == null) 
            return 0;
        
        if (root.left == null 
                && root.right == null) {
            
            E e = (E) root.element;
            
            sum += e.doubleValue();
            
        }
        return sum + zbirListova(root.right) + zbirListova(root.left);
    }


    @Override
    public int getSize() {
        return size;
    }

    @Override
    public Iterator<E> iterator() {
        return null;
    }

    public ListIterator<E> listIterator() {
        return null;
    }

    @Override
    public void clear() {
        root = null;
        size = 0;
    }

    @Override
    protected Object clone() {
        BSTGeneric<E> copy = new BSTGeneric<>();
        Iterator<E> iter = null;
        while (iter.hasNext()) {
            copy.insert(iter.next());
        }
        return copy;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof BSTGeneric)) {
            return false;
        }
        BSTGeneric<E> c = (BSTGeneric<E>) obj;
        ArrayList<E> list1 = null;
        ArrayList<E> list2 = null;
        return list1.equals(list2);
    }

   
    //</editor-fold>
}
