/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Z1;

/**
 *
 * @author Jovan Sekulovic 4211
 */
public class BST_Node<E> {

    public E element;
    public BST_Node<E> left;
    public BST_Node<E> right;

    public BST_Node(E e) {
        this.element = e;
    }
}
